# #### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


from dataclasses import dataclass
from enum import Enum
from functools import lru_cache
from math import radians
from typing import Optional
import atexit
import concurrent.futures
import datetime
import json
import mathutils
import os
import platform
import queue
import re
import shutil
import sys
import threading
import time
import traceback
import urllib.parse

try:
    import ConfigParser
except:
    import configparser as ConfigParser

from bpy.app.handlers import persistent
import bpy.utils.previews
import bmesh

from . import api
from .utils import *
from . import reporting
from . import updater


MAX_PURCHASE_THREADS = 5
MAX_DOWNLOAD_THREADS = 5


# ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


def panel_update(context=None):
    """Force a redraw of the 3D and preferences panel from operator calls."""
    if not context:
        context = bpy.context
    cTB.f_CheckAssets()
    try:
        for wm in bpy.data.window_managers:
            for window in wm.windows:
                for area in window.screen.areas:
                    if area.type not in ("VIEW_3D", "PREFERENCES"):
                        continue
                    for region in area.regions:
                        region.tag_redraw()
    except AttributeError:
        pass  # Startup condition, nothing to redraw anyways.


def last_update_callback(value):
    """Called by the updated module to allow saving in local system."""
    cTB.vSettings["last_update"] = cTB.updater.last_check
    cTB.f_SaveSettings()


# ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


@dataclass
class Notification:
    """Container object for a user notification."""
    class ActionType(Enum):
        OPEN_URL = 1
        UPDATE_READY = 2
        POPUP_MESSAGE = 3

    notification_id: str  # Unique id for this specific kind of notice.
    title: str  # Main title, should be short
    action: ActionType  # Indicator of how to structure and draw notification.
    allow_dismiss: bool = True  # Allow the user to dismiss the notification.
    tooltip: Optional[str] = None  # Hover-over tooltip, if there is a button
    icon: Optional[str] = None  # Blender icon enum to use.

    # Treat below as a "oneof" where only set if the given action is assigned.
    # OPEN_URL
    ac_open_url_address: Optional[str] = None
    ac_open_url_label: Optional[str] = None
    # UPDATE_READY
    ac_update_ready_download_url: Optional[str] = None
    ac_update_ready_download_label: Optional[str] = None
    ac_update_ready_logs_url: Optional[str] = None
    ac_update_ready_logs_label: Optional[str] = None
    # POPUP_MESSAGE
    # If url is populated, opens the given url in a webbrowser, otherwise
    # this popup can just be dismissed.
    ac_popup_message_body: Optional[str] = None
    ac_popup_message_url: Optional[str] = None


@dataclass
class DisplayError:
    """Container object for errors that the addon encountered."""
    button_label: str  # Short label for button drawing
    description: str  # Longer description of the issue and what to do.
    asset_id: str  # Optional value, if specific to a single asset.
    asset_name: str  # Optional value, if specific to a single asset.


def build_update_notification():
    """Construct the a update notification if available."""
    if not cTB.updater.update_ready:
        return

    this_update = cTB.updater.update_data
    vstring = updater.t2v([str(x) for x in this_update.version])
    logs = "https://docs.google.com/document/d/1VtWk60JgaWZxuVwLGdtYbzRofnMCI7IjRXF6okwpYVI/edit?usp=sharing"

    update_notice = Notification(
        notification_id="UPDATE_READY_MANUAL_INSTALL",
        title="Update ready:",
        action=Notification.ActionType.UPDATE_READY,
        tooltip=f"Download the {vstring} update.",
        allow_dismiss=True,
        ac_update_ready_download_url=this_update.url,
        ac_update_ready_download_label="Install",
        ac_update_ready_logs_url=logs,
        ac_update_ready_logs_label="Logs"
    )
    return update_notice


class c_Toolbox:

    # Container for any notifications to show user in the panel UI.
    notifications = []
    # Containers for errors to persist in UI for drawing, e.g. after dload err.
    ui_errors = []

    # Static strings referenced elsewhere:
    ERR_CREDS_FORMAT = "Invalid email format/password length."

    def __init__(self, api_service=None):
        if api_service is None:
            self._api = api.PoliigonConnector(
                software="blender",
                get_optin=reporting.get_optin,
                report_message=reporting.capture_message)
        else:
            self._api = api_service

    def register(cTB, version: str):
        """Deferred registration, to ensure properties exist."""
        cTB.version = version
        software_version = ".".join([str(x) for x in bpy.app.version])
        cTB._api.register_update(cTB.version, software_version)

        cTB.updater = updater.SoftwareUpdater(
            addon_name="poliigon-addon-blender",
            addon_version=updater.v2t(version),
            software_version=bpy.app.version
        )
        cTB.updater.last_check_callback = last_update_callback

        cTB.gScriptDir = os.path.join(os.path.dirname(__file__), "files")
        # Output used to recognize a fresh install (or update).
        any_updated = cTB.update_files(cTB.gScriptDir)

        # TODO(SOFT-58): Defer folder creation and prompt for user path.
        base_dir = os.path.join(
            os.path.expanduser("~").replace("\\", "/"),
            "Poliigon")

        cTB.gSettingsDir = os.path.join(base_dir, "Blender")
        f_MDir(cTB.gSettingsDir)

        cTB.gOnlinePreviews = os.path.join(base_dir, "OnlinePreviews")
        f_MDir(cTB.gOnlinePreviews)

        cTB.gSettingsFile = os.path.join(
            cTB.gSettingsDir, "Poliigon_Blender_Settings.ini")

        # cTB.vAsset = None

        print(":" * 100)
        print("\n", "Starting the Poliigon Addon for Blender...", "\n")
        print(cTB.gSettingsFile)
        print("Toggle verbose logging in addon prefrences")

        cTB.vRunning = 1
        cTB.vRedraw = 0
        cTB.vWidth = 0

        cTB.vRequests = 0

        cTB.vCheckScale = 0

        cTB.vOnline = 1
        cTB.vGettingData = 0

        # Flag which triggers getting local assets again when settings change
        cTB.vRerunGetLocalAssets = False

        cTB.vTimer = time.time()

        cTB.vSettings = {}
        cTB.skip_legacy_settings = ["name", "email"]

        # ......................................................................................

        # Separating UI icons from asset previews.
        cTB.vIcons = bpy.utils.previews.new()
        cTB.vIcons.load("ICON_poliigon",
                        os.path.join(cTB.gScriptDir, "poliigon_logo.png"),
                        "IMAGE")
        cTB.vIcons.load("ICON_myassets",
                        os.path.join(cTB.gScriptDir, "my_assets.png"),
                        "IMAGE")
        cTB.vIcons.load("ICON_new",
                        os.path.join(cTB.gScriptDir, "poliigon_new.png"),
                        "IMAGE")
        cTB.vIcons.load("ICON_import",
                        os.path.join(cTB.gScriptDir, "poliigon_import.png"),
                        "IMAGE")
        cTB.vIcons.load("ICON_apply",
                        os.path.join(cTB.gScriptDir, "poliigon_apply.png"),
                        "IMAGE")
        cTB.vIcons.load("GET_preview",
                        os.path.join(cTB.gScriptDir, "get_preview.png"),
                        "IMAGE")
        cTB.vIcons.load("NO_preview",
                        os.path.join(cTB.gScriptDir, "icon_nopreview.png"),
                        "IMAGE")
        cTB.vIcons.load("NOTIFY",
                        os.path.join(cTB.gScriptDir, "poliigon_notify.png"),
                        "IMAGE")
        cTB.vIcons.load("NEW_RELEASE",
                        os.path.join(cTB.gScriptDir, "poliigon_new.png"),
                        "IMAGE")
        cTB.vIcons.load("ICON_cart",
                        os.path.join(cTB.gScriptDir, "cart_icon.png"),
                        "IMAGE")
        cTB.vIcons.load("ICON_working",
                        os.path.join(cTB.gScriptDir, "icon_working.gif"),
                        "MOVIE")
        cTB.vIcons.load("ICON_dots",
                        os.path.join(cTB.gScriptDir, "icon_dots.png"),
                        "IMAGE")
        cTB.vIcons.load("ICON_acquired_check",
                        os.path.join(cTB.gScriptDir, "acquired_checkmark.png"),
                        "IMAGE")

        cTB.vPreviews = bpy.utils.previews.new()

        cTB.vPreviewsLoaded = []

        # ......................................................................................

        cTB.vUser = {}
        cTB.vUser["name"] = ""
        cTB.vUser["id"] = ""
        cTB.vUser["credits"] = 0
        cTB.vUser["credits_od"] = 0
        cTB.vUser["max_credits"] = 0
        cTB.vUser["plan"] = ""
        cTB.vLoginError = ""

        cTB.vSettings = {}
        cTB.vSettings["res"] = "4K"
        cTB.vSettings["maps"] = []

        cTB.vSuggestions = []

        cTB.vSearch = {}
        cTB.vSearch["poliigon"] = ""
        cTB.vSearch["my_assets"] = ""
        cTB.vSearch["imported"] = ""
        cTB.vLastSearch = ""

        cTB.vPage = {}
        cTB.vPage["poliigon"] = 0
        cTB.vPage["my_assets"] = 0
        cTB.vPage["imported"] = 0
        
        cTB.vPages = {}
        cTB.vPages["poliigon"] = 0
        cTB.vPages["my_assets"] = 0
        cTB.vPages["imported"] = 0
        
        cTB.vGoTop = 0

        cTB.vEditPreset = None

        cTB.vSetup = {}
        cTB.vSetup["size"] = None
        cTB.vSetup["disp"] = 1

        cTB.vPrevScale = 1.0
        cTB.vMatSlot = 0

        cTB.vTexExts = [".jpg", ".png", ".tif", ".exr"]
        cTB.vModExts = [".fbx", ".blend"]

        cTB.vMaps = [
            "ALPHA",
            "ALPHAMASKED",
            "AO",
            "BUMP",
            "BUMP16",
            "COL",
            "DIFF",
            "DISP",
            "DISP16",
            "EMISSIVE",
            "FUZZ",
            "GLOSS",
            "HDR",
            "IDMAP",
            "JPG",
            "MASK",
            "METALNESS",
            "NRM",
            "NRM16",
            "REFL",
            "ROUGHNESS",
            "SSS",
            "TRANSMISSION",
        ]
        cTB.vSizes = ["1K", "2K", "3K", "4K", "6K", "8K", "12K", "16K", "18K", "HIRES"]
        cTB.vLODs = ['SOURCE'] + [f'LOD{i}' for i in range(5)]
        cTB.vVars = [f'VAR{i}' for i in range(1,10)]

        cTB.vModSecondaries = ["Footrest", "Vase"]

        # .....................................................................

        cTB.f_GetSettings()
        cTB.prefs = cTB.get_prefs()
        cTB.ui_errors = []

        cTB.vActiveCat = cTB.vSettings["category"][cTB.vSettings["area"]]
        cTB.vAssetType = cTB.vActiveCat[0]

        if cTB.vSettings["last_update"]:
            cTB.updater.last_check = cTB.vSettings["last_update"]

        if any_updated and not cTB._api.token:
            # This means this was a new install without a local login token.
            # This setup won't pick up installs in new blender instances
            # where no login event had to happen, but will pick up the first
            # install on the same machine.
            now = datetime.datetime.now()
            now_str = now.strftime("%Y-%m-%d %H:%M:%S")
            cTB.vSettings["first_enabled_time"] = now_str
            cTB.f_SaveSettings()

        # .....................................................................

        cTB.vCategories = {}
        cTB.vCategories["poliigon"] = {}
        cTB.vCategories["my_assets"] = {}
        cTB.vCategories["imported"] = {}
        cTB.vCategories["new"] = {}

        cTB.vAssetTypes = ["Textures", "Models", "HDRIs", "Brushes"]

        cTB.vAssets = {}
        cTB.vAssets["poliigon"] = {}
        cTB.vAssets["my_assets"] = {}
        cTB.vAssets["imported"] = {}
        cTB.vAssets["local"] = {}

        # Ensure the base keys always exist:
        for key in cTB.vAssetTypes:
            cTB.vAssets["poliigon"][key] = {}
            cTB.vAssets["my_assets"][key] = {}
            cTB.vAssets["imported"][key] = {}
            cTB.vAssets["local"][key] = {}

        cTB.vAssetsIndex = {}
        cTB.vAssetsIndex["poliigon"] = {}
        cTB.vAssetsIndex["my_assets"] = {}
        cTB.vAssetsIndex["imported"] = {}

        cTB.vPurchased = []

        # ..................................................

        cTB.vInterrupt = time.time()

        cTB.vInvalid = 0

        cTB.vWorking = {}
        cTB.vWorking["login"] = 0
        cTB.vWorking["startup"] = False

        cTB.vThreads = []

        cTB.vDownloadQueue = {}
        cTB.vPurchaseQueue = {}
        cTB.vDownloadCancelled = set()
        cTB.vPreviewsQueue = []
        cTB.vQuickPreviewQueue = {}

        cTB.vDownloadFailed = {}
        
        cTB.purchase_queue = queue.Queue()
        cTB.purchase_threads = []
        
        cTB.download_queue = queue.Queue()
        cTB.download_threads = []
        
        cTB.vPreviewsDownloading = []

        cTB.vGettingData = 1
        cTB.vWasWorking = False  # Identify if at last check, was still running.
        cTB.vGettingLocalAssets = 0
        cTB.vGotLocalAssets = 0
        
        cTB.vGettingPages = {}
        cTB.vGettingPages["poliigon"] = []
        cTB.vGettingPages["my_assets"] = []
        cTB.vGettingPages["imported"] = []

        cTB.f_GetCredits()
        cTB.f_GetUserInfo()

        # cTB.f_APIGetLatest()
        cTB.f_GetAssets("my_assets", vMax=5000, vBackground=1)
        cTB.f_GetAssets()
        cTB.f_GetCategories()
        cTB.f_GetLocalAssets()

        cTB.vSortedAssets = []

        # ..................................................

        cTB.vActiveObjects = []
        cTB.vActiveAsset = None
        cTB.vActiveMat = None
        cTB.vActiveMatProps = {}
        cTB.vActiveTextures = {}
        cTB.vActiveFaces = {}
        cTB.vActiveMode = None

        cTB.vActiveMixProps = {}
        cTB.vActiveMix = None
        cTB.vActiveMixMat = None
        cTB.vMixTexture = ""

        cTB.vPropDefaults = {}
        cTB.vPropDefaults["Scale"] = 1.0
        cTB.vPropDefaults["Aspect Ratio"] = 1.0
        cTB.vPropDefaults["Normal Strength"] = 1.0
        cTB.vPropDefaults["Mix Texture Value"] = 0.0
        cTB.vPropDefaults["Mix Noise Value"] = 1.0
        cTB.vPropDefaults["Noise Scale"] = 5.0
        cTB.vPropDefaults["Noise Detail"] = 2.0
        cTB.vPropDefaults["Noise Roughness"] = 5.0
        cTB.vPropDefaults["Mix Softness"] = 0.5
        cTB.vPropDefaults["Mix Bias"] = 5.0

        cTB.vAllMats = None

        cTB.vInitialScreenViewed = False

        # Cache of time.time() to know if user too-recently tried to change
        # pages, thus causing potential icon loading issues with blender. Used
        # to trigger refresh_data.
        cTB.vLastPageChange = 0  # Cache of time.time()
        cTB.vReloadTriggerInterval = 0.5  # Triggered if less than interval.

    # ...............................................................................................

    def f_GetSettings(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetSettings")

        cTB.vSettings = {}
        cTB.vSettings["add_dirs"] = []
        cTB.vSettings["area"] = "poliigon"
        cTB.vSettings["auto_download"] = 1
        cTB.vSettings["category"] = {}
        cTB.vSettings["category"]["imported"] = ["All Assets"]
        cTB.vSettings["category"]["my_assets"] = ["All Assets"]
        cTB.vSettings["category"]["poliigon"] = ["All Assets"]
        cTB.vSettings["conform"] = 0
        cTB.vSettings["default_lod"] = "LOD1"
        cTB.vSettings["del_zip"] = 1
        cTB.vSettings["disabled_dirs"] = []
        cTB.vSettings["download_lods"] = 1
        cTB.vSettings["hide_labels"] = 1
        cTB.vSettings["hide_scene"] = 0
        cTB.vSettings["hide_suggest"] = 0
        cTB.vSettings["library"] = ""
        cTB.vSettings["location"] = "Properties"
        cTB.vSettings["mapping_type"] = "UV + UberMapping"
        cTB.vSettings["mat_props"] = []
        cTB.vSettings["mix_props"] = []
        cTB.vSettings["new_release"] = ""
        cTB.vSettings["last_update"] = ""
        cTB.vSettings["new_top"] = 1
        cTB.vSettings["notify"] = 5
        cTB.vSettings["open_count"] = 0
        cTB.vSettings["page"] = 10
        cTB.vSettings["preview_size"] = 7
        cTB.vSettings["previews"] = 1
        cTB.vSettings["set_library"] = ""
        cTB.vSettings["show_active"] = 1
        cTB.vSettings["show_add_dir"] = 1
        cTB.vSettings["show_asset_info"] = 1
        cTB.vSettings["show_credits"] = 1
        cTB.vSettings["show_default_prefs"] = 1
        cTB.vSettings["show_display_prefs"] = 1
        cTB.vSettings["show_import_prefs"] = 1
        cTB.vSettings["show_mat_ops"] = 0
        cTB.vSettings["show_mat_props"] = 0
        cTB.vSettings["show_mat_texs"] = 0
        cTB.vSettings["show_mix_props"] = 1
        cTB.vSettings["show_pass"] = 0
        cTB.vSettings["show_plan"] = 1
        cTB.vSettings["show_settings"] = 0
        cTB.vSettings["show_user"] = 0
        cTB.vSettings["sorting"] = "Latest"
        cTB.vSettings["unzip"] = 1
        cTB.vSettings["update_sel"] = 1
        cTB.vSettings["use_16"] = 1
        cTB.vSettings["use_ao"] = 1
        cTB.vSettings["use_bump"] = 1
        cTB.vSettings["use_disp"] = 1
        cTB.vSettings["use_subdiv"] = 1
        cTB.vSettings["version"] = cTB.version
        cTB.vSettings["win_scale"] = 1
        cTB.vSettings["first_enabled_time"] = ""

        cTB.vSettings["res"] = "4K"
        cTB.vSettings["lod"] = "SOURCE"
        cTB.vSettings["mres"] = "4K"
        cTB.vSettings["hdri"] = "4K"
        cTB.vSettings["hdrib"] = "8K"
        cTB.vSettings["hdrif"] = "EXR"
        cTB.vSettings["brush"] = "2K"
        cTB.vSettings["maps"] = cTB.vMaps

        # ...............................................................................................

        cTB.check_dpi()

        # ...............................................................................................

        cTB.vPresets = {}
        cTB.vMixPresets = {}

        cTB.vReleases = {}

        # ...............................................................................................

        if f_Ex(cTB.gSettingsFile):
            vConfig = ConfigParser.ConfigParser()
            vConfig.optionxform = str
            vConfig.read(cTB.gSettingsFile)

            if vConfig.has_section("user"):
                for vK in vConfig.options("user"):
                    if vK in cTB.skip_legacy_settings:
                        continue
                    if "credit" in vK:
                        cTB.vUser[vK] = int(vConfig.get("user", vK))
                    elif vK == "token":
                        token = vConfig.get("user", "token")
                        if token and token != "None":
                            cTB._api.token = vConfig.get("user", "token")
                    else:
                        cTB.vUser[vK] = vConfig.get("user", vK)

                if cTB.vUser["id"]:
                    reporting.assign_user(cTB.vUser["id"])

            else:
                os.remove(cTB.gSettingsFile)
                vConfig = ConfigParser.ConfigParser()

            if vConfig.has_section("settings"):
                vVer = None
                if vConfig.has_option("settings", "version"):
                    vVer = vConfig.get("settings", "version")

                for vS in vConfig.options("settings"):
                    if vS.startswith("category"):
                        try:
                            vArea = vS.replace("category_", "")
                            cTB.vSettings["category"][vArea] = vConfig.get(
                                "settings", vS
                            ).split("/")
                            if "" in cTB.vSettings[vS]:
                                cTB.vSettings["category"][vArea].remove("")
                        except:
                            pass
                    else:
                        cTB.vSettings[vS] = vConfig.get("settings", vS)

                        if vS in [
                            "add_dirs",
                            "disabled_dirs",
                            "mat_props",
                            "mix_props",
                        ]:
                            cTB.vSettings[vS] = cTB.vSettings[vS].split(";")
                            if "" in cTB.vSettings[vS]:
                                cTB.vSettings[vS].remove("")
                        elif cTB.vSettings[vS] == "True":
                            cTB.vSettings[vS] = 1
                        elif cTB.vSettings[vS] == "False":
                            cTB.vSettings[vS] = 0
                        else:
                            try:
                                cTB.vSettings[vS] = int(cTB.vSettings[vS])
                            except:
                                try:
                                    cTB.vSettings[vS] = float(cTB.vSettings[vS])
                                except:
                                    pass

            if vConfig.has_section("presets"):
                for vP in vConfig.options("presets"):
                    try:
                        cTB.vPresets[vP] = [
                            float(vV) for vV in vConfig.get("presets", vP).split(";")
                        ]
                    except:
                        pass

            if vConfig.has_section("mixpresets"):
                for vP in vConfig.options("mixpresets"):
                    try:
                        cTB.vMixPresets[vP] = [
                            float(vV) for vV in vConfig.get("mixpresets", vP).split(";")
                        ]
                    except:
                        pass

            if vConfig.has_section("download"):
                for vO in vConfig.options("download"):
                    if vO == "res":
                        cTB.vSettings["res"] = vConfig.get("download", vO)
                    elif vO == "maps":
                        cTB.vSettings["maps"] = vConfig.get("download", vO).split(";")

        # ...............................................................................................

        cTB.vSettings["open_count"] += 1

        if cTB.vSettings["open_count"] > cTB.vSettings["notify"]:
            if not cTB.notifications:
                # Only add the feedback message if sufficient open count,
                # and there aren't existing notifications.
                feedback_url = "https://help.poliigon.com/articles/6342599-poliigon-addon-for-blender"
                feedback_url = cTB._api.add_utm_suffix(feedback_url)
                feedback_notice = Notification(
                    notification_id="ASK_FEEDBACK",
                    title="Do you have any feedback?",
                    action=Notification.ActionType.OPEN_URL,
                    ac_open_url_address=feedback_url,
                    ac_open_url_label="Share here",
                    icon="NOTIFY"
                )
                # Skipping until post launch for general feedback form.
                # cTB.notifications.append(feedback_notice)

        # ...............................................................................................

        # cTB.vSettings["library"] = ""
        if cTB.vSettings["library"] == "":
            cTB.vSettings["set_library"] = cTB.gSettingsDir.replace("Blender", "Library")

        cTB.vSettings["show_user"] = 0
        cTB.vSettings["mat_props_edit"] = 0

        cTB.vSettings["area"] = "poliigon"
        cTB.vSettings["category"]["poliigon"] = ["All Assets"]
        cTB.vSettings["category"]["imported"] = ["All Assets"]
        cTB.vSettings["category"]["my_assets"] = ["All Assets"]

        cTB.f_SaveSettings()

    def f_SaveSettings(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_SaveSettings")

        vConfig = ConfigParser.ConfigParser()
        vConfig.optionxform = str
        vConfig.read(cTB.gSettingsFile)

        # ................................................

        if not vConfig.has_section("user"):
            vConfig.add_section("user")

        for vK in cTB.vUser.keys():
            if vK in cTB.skip_legacy_settings:
                vConfig.remove_option("user", vK)
                continue
            vConfig.set("user", vK, str(cTB.vUser[vK]))

        # Save token as if cTB field, on load will be parsed to _api.token
        vConfig.set("user", "token", str(cTB._api.token))

        # ................................................

        if not vConfig.has_section("settings"):
            vConfig.add_section("settings")

        for vS in cTB.vSettings.keys():
            if vS == "category":
                for vA in cTB.vSettings[vS].keys():
                    vConfig.set(
                        "settings", vS + "_" + vA, "/".join(cTB.vSettings[vS][vA])
                    )

            elif vS in ["add_dirs", "disabled_dirs", "mat_props", "mix_props"]:
                vConfig.set("settings", vS, ";".join(cTB.vSettings[vS]))

            else:
                vConfig.set("settings", vS, str(cTB.vSettings[vS]))

        # ................................................

        if not vConfig.has_section("presets"):
            vConfig.add_section("presets")

        for vP in cTB.vPresets.keys():
            vConfig.set("presets", vP, ";".join([str(vV) for vV in cTB.vPresets[vP]]))

        # ................................................

        if not vConfig.has_section("mixpresets"):
            vConfig.add_section("mixpresets")

        for vP in cTB.vMixPresets.keys():
            vConfig.set(
                "mixpresets", vP, ";".join([str(vV) for vV in cTB.vMixPresets[vP]])
            )

        # ................................................

        if vConfig.has_section("download"):
            vConfig.remove_section("download")
        vConfig.add_section("download")

        for vK in cTB.vSettings:
            if vK == "res":
                vConfig.set("download", vK, cTB.vSettings[vK])
            elif vK == "maps":
                vConfig.set("download", vK, ";".join(cTB.vSettings[vK]))

        # ................................................

        f_MDir(cTB.gSettingsDir)

        with open(cTB.gSettingsFile, "w+") as vFile:
            vConfig.write(vFile)

    # .........................................................................

    def refresh_ui(self):
        """Wrapper to decouple blender UI drawing from callers of cTB."""
        panel_update(bpy.context)

    def check_dpi(self):
        """Checks the DPI of the screen to adjust the scale accordingly.

        Used to ensure previews remain square and avoid text truncation.
        """
        prefs = bpy.context.preferences

        # This was found empirically.
        # The `pixel_size` field actually acts like an integer. As ui_scale
        # increases from 1.0 (float value) at a certain point, pixel_size
        # will jump from 1 to 2 (or from 2 to 3 on retina displays).
        # However, this ratio of pixel_size to ui_scale reveals what the values
        # would be when ui_scale = 1, to help indicate if this display should
        # is actually rendering 2x.
        # Note: This does not hold for ui_scale values < 1.0, which won't be
        # common anyways.
        if prefs.system.pixel_size / prefs.view.ui_scale > 1.5:
            scale = 2
        else:
            scale = 1

        # Technically dpi is deprecated, use ui_scale instead.
        # dpi_factor = 72 / bpy.context.preferences.system.dpi

        # Don't use pixel_size, as it causes jumps acting like an int.
        # scale = bpy.context.preferences.system.pixel_size

        cTB.vSettings["win_scale"] = prefs.view.ui_scale * scale

    def get_ui_scale(self):
        """Utility for fetching the ui scale, used in draw code."""
        self.check_dpi()
        return cTB.vSettings["win_scale"]

    def check_if_working(self):
        """See if the toolbox is currently running an operation."""
        # Not including `cTB.vGettingData` as that is just a flag for
        # displaying placeholders in the UI.
        res = 1 in list(cTB.vWorking.values())
        if res:
            self.vWasWorking = res
        return res

    # .........................................................................

    def is_logged_in(self):
        """Returns whether or not the user is currently logged in."""
        return self._api.token is not None and not self._api.invalidated

    def user_invalidated(self):
        """Returns whether or not the user token was invalidated."""
        return self._api.invalidated

    def clear_user_invalidated(self):
        """Clears any invalidation flag for a user."""
        self._api.invalidated = False

    def check_backplate(self, asset_name):
        """Return bool on whether this asset is a backplate."""
        lwr = asset_name.lower()
        return any(
            lwr.startswith(vS) for vS in ["backdrop", "backplate"])

    # .........................................................................

    def initial_view_screen(self):
        """Reports view from a draw panel, to avoid triggering until use."""
        if self.vInitialScreenViewed is True:
            return
        self.vInitialScreenViewed = True
        self.track_screen_from_area()

    def track_screen_from_area(self):
        """Signals the active screen in background if opted in"""
        area = self.vSettings["area"]
        if area == "poliigon":
            cTB.track_screen("home")
        elif area == "my_assets":
            cTB.track_screen("my_assets")
        elif area == "imported":
            cTB.track_screen("imported")
        elif area == "account":
            cTB.track_screen("my_account")

    def track_screen(self, area):
        """Signals input screen area in a background thread if opted in."""
        if not self._api._is_opted_in():
            return
        vThread = threading.Thread(
            target=cTB._api.signal_view_screen,
            args=(area,),
        )
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    def register_notification(self, notice):
        """Stores and displays a new notification banner and signals event."""
        # Clear any notifications with the same id.
        for existing_notice in self.notifications:
            if existing_notice.notification_id == notice.notification_id:
                cTB.notifications.pop(existing_notice)
        self.notifications.append(notice)

        if not self._api._is_opted_in():
            return

        vThread = threading.Thread(
            target=self._api.signal_view_notification,
            args=(notice.notification_id,),
        )
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    def click_notification(self, notice_id, action):
        """Signals event for click notification."""
        if not self._api._is_opted_in():
            return
        vThread = threading.Thread(
            target=self._api.signal_click_notification,
            args=(notice_id, action,),
        )
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    def dismiss_notification(self, notice_id):
        """Signals dismissed notification in background if user opted in."""
        if not self._api._is_opted_in():
            return
        vThread = threading.Thread(
            target=self._api.signal_dismiss_notification,
            args=(notice_id,),
        )
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    def signal_import_asset(self, asset_id):
        """Signals an asset import in the background if user opted in."""
        if not self._api._is_opted_in():
            return
        vThread = threading.Thread(
            target=self._api.signal_import_asset,
            args=(asset_id,),
        )
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    # .........................................................................

    #@timer
    def f_Login(cTB, vMode):
        cTB.clear_user_invalidated()
        dbg = 0
        cTB.print_separator(dbg, "f_Login")
        if vMode == "login":

            elapsed_s = None
            if cTB.vSettings["first_enabled_time"]:
                now = datetime.datetime.now()
                install_tstr = cTB.vSettings["first_enabled_time"]
                install_t = datetime.datetime.strptime(
                    install_tstr, "%Y-%m-%d %H:%M:%S")
                elapsed = now - install_t
                elapsed_s = int(elapsed.total_seconds())
                if elapsed_s <= 0:
                    cTB.print_debug(0, "Throwing out negative elapsed time")
                    elapsed_s = None

            vReq = cTB._api.log_in(
                bpy.context.window_manager.poliigon_props.vEmail,
                bpy.context.window_manager.poliigon_props.vPassHide,
                time_since_enable=elapsed_s)

            if vReq.ok:
                vData = vReq.body

                cTB.vUser["name"] = vData["user"]["name"]
                cTB.vUser["id"] = vData["user"]["id"]

                # Ensure logging is associated with this user.
                reporting.assign_user(cTB.vUser["id"])

                cTB.vUser["credits"] = 0
                cTB.vUser["credits_od"] = 0
                cTB.vUser["max_credits"] = 0
                cTB.vUser["plan"] = None

                cTB.f_GetCredits()
                cTB.f_GetCategories()
                cTB.f_GetAssets("my_assets", vMax=5000, vBackground=1)
                cTB.f_GetAssets()

                cTB.vLoginError = ""

                # Clear out password after login attempt
                bpy.context.window_manager.poliigon_props.vPassHide = ""
                bpy.context.window_manager.poliigon_props.vPassShow = ""

                # Reset navigation on login
                cTB.vSettings["area"] = "poliigon"
                cTB.track_screen_from_area()

                cTB.vSettings["category"]["imported"] = ["All Assets"]
                cTB.vSettings["category"]["my_assets"] = ["All Assets"]
                cTB.vSettings["category"]["poliigon"] = ["All Assets"]
                cTB.vSettings["show_settings"] = 0
                cTB.vSettings["show_user"] = 0

                cTB.print_debug(dbg, "f_Login", "Login success")

                # Clear time since install since successful.
                if elapsed_s is not None:
                    cTB.vSettings["first_enabled_time"] = ""
                    cTB.f_SaveSettings()

            else:
                cTB.print_debug(dbg, "f_Login", "ERROR", vReq.error)
                reporting.capture_message("login_error", vReq.error, 'error')
                cTB.vLoginError = vReq.error
            cTB.refresh_ui()

        elif vMode == "logout":
            req = cTB._api.log_out()
            if req.ok:
                cTB.print_debug(dbg, "f_Login", "Logout success")
            else:
                cTB.print_debug(dbg, "f_Login", "ERROR", req.error)
                reporting.capture_message("logout_error", req.error, 'error')

            cTB._api.token = None

            # Clear out all user fields on logout.
            cTB.vUser["credits"] = 0
            cTB.vUser["credits_od"] = 0
            cTB.vUser["max_credits"] = 0
            cTB.vUser["plan"] = None
            cTB.vUser["token"] = None
            cTB.vUser["name"] = None
            cTB.vUser["id"] = None

            bpy.context.window_manager.poliigon_props.vEmail = ""
            bpy.context.window_manager.poliigon_props.vPassHide = ""
            bpy.context.window_manager.poliigon_props.vPassShow = ""

            cTB.refresh_ui()

        cTB.f_SaveSettings()

        cTB.vWorking["login"] = 0

        cTB.vRedraw = 1
        cTB.refresh_ui()

    # .........................................................................

    def f_GetCategories(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetCategories")

        vThread = threading.Thread(target=cTB.f_APIGetCategories)
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    def f_GetCategoryChildren(cTB, vType, vCat):
        dbg = 0
        # cTB.print_separator(dbg, "f_GetCategoryChildren")

        vChldrn = vCat["children"]
        for vC in vChldrn:
            vPath = []
            for vS in vC["path"].split("/"):
                vS = " ".join([vS1.capitalize() for vS1 in vS.split("-")])
                vPath.append(vS)

            vPath = ("/".join(vPath)).replace("/" + vType + "/", "/")
            vPath = vPath.replace("/Hdrs/", "/")

            if "Generators" in vPath:
                continue

            # cTB.print_debug(dbg, "f_GetCategoryChildren", vPath)

            cTB.vCategories["poliigon"][vType][vPath] = []

            if len(vC["children"]):
                cTB.f_GetCategoryChildren(vType, vC)

    @reporting.handle_function(silent=True)
    def f_APIGetCategories(cTB):
        """Fetch and save categories to file."""
        dbg = 0
        cTB.print_separator(dbg, "f_APIGetCategories")
        vReq = cTB._api.categories()
        if vReq.ok:
            # cTB.print_debug(dbg, "f_APIGetCategories", str(vReq.body))
            if not len(vReq.body):
                cTB.print_debug(
                    dbg, "f_APIGetCategories", "ERROR",
                    vReq.error, ", ", vReq.body)

            for vC in vReq.body:
                vType = vC["name"]
                cTB.print_debug(dbg, "f_APIGetCategories", vType)
                if vType not in cTB.vCategories["poliigon"].keys():
                    cTB.vCategories["poliigon"][vType] = {}
                cTB.f_GetCategoryChildren(vType, vC)
                cTB.print_debug(
                    dbg, "f_APIGetCategories",
                    str(cTB.vCategories["poliigon"][vType]))

            vDataFile = os.path.join(cTB.gSettingsDir, "TB_Categories.json")
            with open(vDataFile, "w") as vWrite:
                json.dump(cTB.vCategories, vWrite)
        cTB.refresh_ui()

    # .........................................................................

    #@timer
    def f_GetAssets(cTB, vArea=None, vPage=None, vMax=None,
                    vBackground=0, vUseThread=True):
        dbg = 0
        cTB.print_separator(dbg, "f_GetAssets")
        cTB.print_debug(dbg, "f_GetAssets", vArea, vPage, vMax, vBackground)

        if vArea is None:
            vArea = cTB.vSettings["area"]

        if vPage is None:
            vPage = cTB.vPage[vArea]

        if vMax is None:
            vMax = cTB.vSettings["page"]

        vPageAssets, vPageCount = cTB.f_GetPageAssets(vPage)
        if len(vPageAssets):
            return

        # .........................................................................

        if vPage in cTB.vGettingPages[vArea]:
            return

        cTB.vGettingPages[vArea].append(vPage)

        vSearch = cTB.vSearch[vArea]

        vKey = "/".join([vArea] + cTB.vSettings['category'][vArea])
        if vSearch != "":
            vKey = "@".join(
                [vArea] + cTB.vSettings['category'][vArea] + [vSearch]
            )
        cTB.print_debug(dbg, "f_GetAssets", vKey)
        now = time.time()

        if vUseThread:
            args = (vArea, vPage, vMax, vSearch, vKey, vBackground, now)
            vThread = threading.Thread(
                target=cTB.f_APIGetAssets,
                args=args
            )
            vThread.daemon = 1
            vThread.start()
            cTB.vThreads.append(vThread)
        else:
            cTB.f_APIGetAssets(
                vArea, vPage, vMax, vSearch, vKey, vBackground, now)

    @reporting.handle_function(silent=True)
    def f_APIGetAssets(cTB, vArea, vPage, vMax, vSearch, vKey, vBackground, vTime):
        dbg = 0
        cTB.print_separator(dbg, "f_APIGetAssets")
        cTB.print_debug(
            dbg, "f_APIGetAssets", vPage + 1, vMax, vKey, vBackground, vTime)

        # ...............................................................

        if not cTB.vRunning:
            return

        if not vBackground:
            cTB.vGettingData = 1

        # ...............................................................

        vGetPage = int((vPage * cTB.vSettings["page"]) / vMax)

        vData = {
            "query": vSearch,
            "page": vGetPage + 1,
            "perPage": vMax,
            "algoliaParams": {"facetFilters": [], "numericFilters": ["Credit>=0"]},
        }

        vCat = cTB.vSettings["category"][vArea][0]

        if len(cTB.vSettings["category"][vArea]) > 1:
            if cTB.vSettings["category"][vArea][1] == "Free":
                vData["algoliaParams"]["numericFilters"] = ["Credit=0"]

            if vCat == "All Assets":
                vData["algoliaParams"]["facetFilters"] = [[]]
                for vType in cTB.vAssetTypes:
                    if (
                        "/" + cTB.vSettings["category"][vArea][1]
                        in cTB.vCategories[vArea][vType].keys()
                    ):
                        vCat = [vType] + cTB.vSettings["category"][vArea][1:]
                        vLvl = len(vCat) - 1
                        vCat = " > ".join(vCat).replace("HDRIs", "HDRs")
                        vData["algoliaParams"]["facetFilters"][0].append(
                            "RefineCategories.lvl" + str(vLvl) + ":" + vCat
                        )

            else:
                vLvl = len(cTB.vSettings["category"][vArea]) - 1
                vCat = " > ".join(cTB.vSettings["category"][vArea])
                vCat = vCat.replace("HDRIs", "HDRs")
                vData["algoliaParams"]["facetFilters"] = [
                    "RefineCategories.lvl" + str(vLvl) + ":" + vCat
                ]

        elif vCat != "All Assets":
            vCat = vCat.replace("HDRIs", "HDRs")
            vData["algoliaParams"]["facetFilters"] = ["RefineCategories.lvl0:" + vCat]

        cTB.print_debug(dbg, "f_APIGetAssets", json.dumps(vData))

        # ...............................................................

        if cTB.vInterrupt > vTime or not cTB.vRunning:
            return

        check_owned = vArea == "my_assets"
        if check_owned:
            vReq = cTB._api.get_user_assets(query_data=vData)
        else:
            vReq = cTB._api.get_assets(query_data=vData)

        if vPage in cTB.vGettingPages[vArea]:
            cTB.vGettingPages[vArea].remove(vPage)

        # ...............................................................

        if vReq.ok:
            try:
                vData = vReq.body.get("data")
            except:
                return

            total = vReq.body.get("total")
            cTB.print_debug(
                dbg,
                "f_APIGetAssets",
                f"{len(vData)} assets ({total} total)"
            )

            vPages = int((vReq.body.get("total") / cTB.vSettings["page"]) + 0.999)

            if not vBackground and vPage == cTB.vPage[vArea]:
                cTB.vPages[vArea] = vPages

            if vKey not in cTB.vAssetsIndex[vArea].keys():
                cTB.vAssetsIndex[vArea][vKey] = {}
                cTB.vAssetsIndex[vArea][vKey]["pages"] = vPages

            cTB.print_debug(dbg, "f_APIGetAssets", len(vData), vPages, "pages")

            vIdx = vGetPage * vMax

            for vA in vData:
                vType = vA["type"].replace("HDRS", "HDRIs")

                if vType == "Substances":
                    continue

                if vType not in cTB.vAssets[vArea].keys():
                    cTB.vAssets[vArea][vType] = {}

                vName = vA["asset_name"]

                if vArea == "my_assets" and vName not in cTB.vPurchased:
                    cTB.vPurchased.append(vName)

                # TODO: Turn this into a dataclass structure to avoid keying.
                cTB.vAssets[vArea][vType][vName] = {}
                cTB.vAssets[vArea][vType][vName]["name"] = vName
                cTB.vAssets[vArea][vType][vName]["id"] = vA["id"]
                cTB.vAssets[vArea][vType][vName]["slug"] = vA["slug"]
                cTB.vAssets[vArea][vType][vName]["type"] = vType
                cTB.vAssets[vArea][vType][vName]["files"] = []
                cTB.vAssets[vArea][vType][vName]["maps"] = []
                cTB.vAssets[vArea][vType][vName]["lods"] = []
                cTB.vAssets[vArea][vType][vName]["sizes"] = []
                cTB.vAssets[vArea][vType][vName]["workflows"] = []
                cTB.vAssets[vArea][vType][vName]["vars"] = []
                cTB.vAssets[vArea][vType][vName]["date"] = vA["published_at"]
                cTB.vAssets[vArea][vType][vName]["credits"] = vA["credit"]
                cTB.vAssets[vArea][vType][vName]["categories"] = vA["categories"]
                cTB.vAssets[vArea][vType][vName]["preview"] = ""
                cTB.vAssets[vArea][vType][vName]["thumbnails"] = []
                cTB.vAssets[vArea][vType][vName]["quick_preview"] = vA["toolbox_previews"]
                
                if "lods" in vA.keys():
                    cTB.vAssets[vArea][vType][vName]["lods"] = vA["lods"]

                if len(vA["previews"]):
                    # Primary thumbnail previews
                    cTB.vAssets[vArea][vType][vName]["preview"] = vA["previews"][0]
                    # Additional previews, skipping e.g. mview files.
                    valid = [x for x in vA["previews"]
                             if ".png" in x or ".jpg" in x]
                    cTB.vAssets[vArea][vType][vName]["thumbnails"] = valid

                if vType in ["Textures", "HDRIs", "Brushes"]:
                    if "render_schema" in vA.keys():
                        for vR in vA["render_schema"]:
                            if "name" in vR.keys():
                                if vR["name"] not in cTB.vAssets[vArea][vType][vName]["workflows"] :
                                    cTB.vAssets[vArea][vType][vName]["workflows"].append(vR["name"])
                            
                            if "types" in vR.keys():
                                for vM in vR["types"]:
                                    cTB.vAssets[vArea][vType][vName]["maps"].append(
                                        vM["type_code"]
                                    )
                                    cTB.vAssets[vArea][vType][vName]["sizes"] = vM[
                                        "type_options"
                                    ]
                elif vType == "Models":
                    #print(json.dumps(vA, indent=1))
                    cTB.vAssets[vArea][vType][vName]["workflows"] = ["METALNESS"]
                    
                    cTB.vAssets[vArea][vType][vName]["sizes"] = vA["render_schema"]["options"]
                
                # Sort Sizes
                cTB.vAssets[vArea][vType][vName]["sizes"] = [vS for vS in cTB.vSizes if vS in cTB.vAssets[vArea][vType][vName]["sizes"]]

                cTB.vAssetsIndex[vArea][vKey][vIdx] = [vType, vName]

                cTB.vRedraw = 1
                cTB.refresh_ui()

                vIdx += 1
            
            if cTB.vInterrupt > vTime or not cTB.vRunning:
                return

            if not vBackground and vPage == cTB.vPage[vArea]:
                cTB.vGettingData = 0

                cTB.vRedraw = 1
                cTB.refresh_ui()

        else:
            cTB.print_debug(dbg, "f_APIGetAssets", "ERROR", vReq.error)

    def f_APIGetLatest(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_APIGetLatest")

        # ...............................................................

        if not cTB.vRunning:
            return

        # ...............................................................

        vData = {
            "query": "",
            "page": "1",
            "perPage": "1",
            "algoliaParams": {"facetFilters": [], "numericFilters": ["Credit>=0"]},
        }

        cTB.print_debug(dbg, "f_APIGetLatest", json.dumps(vData))

        # ...............................................................

        vReq = cTB._api.get_assets(query_data=vData)

        # ...............................................................

        if vReq.ok:
            vData = vReq.body.get("data")
            if not vData:
                return

            cTB.vRedraw = 1
            cTB.refresh_ui()

        else:
            cTB.print_debug(dbg, "f_APIGetLatest", "ERROR", vReq.json())

    #@timer
    def f_GetPageAssets(cTB, vPage):
        dbg = 0
        cTB.print_separator(dbg, "f_GetPageAssets")

        vArea = cTB.vSettings["area"]

        vSearch = cTB.vSearch[vArea]

        vMax = cTB.vSettings["page"]

        vPageAssets = []
        vPageCount = 0
        if vArea in cTB.vAssetsIndex.keys():
            vKey = "/".join([vArea] + cTB.vSettings['category'][vArea])
            if vSearch != "":
                vKey = "@".join([vArea] + cTB.vSettings['category'][vArea] + [vSearch])

            cTB.print_debug(dbg, "f_GetPageAssets", vKey)

            if vKey in cTB.vAssetsIndex[vArea].keys():
                for i in range(vPage * vMax, (vPage * vMax) + vMax):
                    if i in cTB.vAssetsIndex[vArea][vKey].keys():
                        vType, vAsset = cTB.vAssetsIndex[vArea][vKey][i]

                        vPageAssets.append(cTB.vAssets[vArea][vType][vAsset])

                vPageCount = cTB.vAssetsIndex[vArea][vKey]['pages']

        return [vPageAssets, vPageCount]

    #@timer
    def f_GetAssetsSorted(cTB, vPage):
        dbg = 0
        cTB.print_separator(dbg, "f_GetAssetsSorted")

        vArea = cTB.vSettings["area"]
        vSearch = cTB.vSearch[vArea]

        if vArea in ["poliigon", "my_assets"]:
            vPageAssets, vPageCount = cTB.f_GetPageAssets(vPage)
            if len(vPageAssets):
                cTB.vPages[vArea] = vPageCount
                return vPageAssets

            if cTB.vGettingData:
                cTB.print_debug(dbg, "f_GetAssetsSorted", "f_DummyAssets")
                return cTB.f_DummyAssets()

            else:
                cTB.print_debug(dbg, "f_GetAssetsSorted", "[]")
                return []

        else:
            vAssetType = cTB.vSettings["category"]["imported"][0]

            vSortedAssets = []
            for vType in list(cTB.vAssets["imported"].keys()):
                if vAssetType in ["All Assets", vType]:
                    for vA in cTB.vAssets["imported"][vType].keys():
                        if (
                            len(vSearch) >= 3
                            and vSearch.lower() not in vA.lower()
                        ):
                            continue

                        if vType in cTB.vAssets["local"].keys():
                            if vA in cTB.vAssets["local"][vType].keys():
                                vSortedAssets.append(cTB.vAssets["local"][vType][vA])

            cTB.vPages[vArea] = int(
                (len(vSortedAssets) / cTB.vSettings["page"]) + 0.99999
            )

            return vSortedAssets

    def get_poliigon_asset(self, vType, vAsset):
        """Get the data for a single explicit asset of a given type."""
        if vType not in self.vAssets["poliigon"]:
            cTB.print_debug(0, f"Was missing {vType}, populated now")
            self.vAssets["poliigon"][vType] = {}

        if vAsset not in self.vAssets["poliigon"][vType]:
            # Handle a given datapoint being missing at moment of request
            # and fetch it.
            # raise Exception("Asset is not avaialble")


            # This is the exception, not the norm, and should be trated as a
            # warning. This would mostly occur when there is a cache miss if
            # an operator is called for an arbitrary asset from an automated
            # script and not from within the normal use of the plugin.
            self.print_debug(
                0,
                "get_poliigon_asset",
                f"Had to fetch asset info for {vAsset}")
            vArea = "poliigon"
            vSearch = vAsset
            vKey = "@".join([vArea] + cTB.vSettings['category'][vArea] + [vSearch])

            vPage = 0
            vMax = 100
            self.f_APIGetAssets(
                vArea, vPage, vMax, vSearch, vKey, 0, time.time())

            if not self.vAssets["poliigon"][vType].get(vAsset):
                raise RuntimeError("Failed to fetch asset information")
            else:
                # Report this cache miss, as generally shouln't happen.
                reporting.capture_message("get_asset_miss", vAsset, 'error')

        return self.vAssets["poliigon"][vType].get(vAsset)

    def get_data_for_asset_id(self, asset_id):
        """Get the data structure for an asset by asset_id alone."""
        area_order = ["poliigon", "my_assets", "local"]
        for area in area_order:
            subcats = list(self.vAssets[area])
            for cat in subcats:  # e.g. HDRIs
                for asset in self.vAssets[area][cat]:
                    if self.vAssets[area][cat][asset].get("id") == asset_id:
                        return self.vAssets[area][cat][asset]

        # Failed to fetch asset, return empty structure.
        return {}

    def get_data_for_asset_name(self, asset_name):
        """Get the data structure for an asset by asset_name alone."""
        area_order = ["poliigon", "my_assets", "local"]
        for area in area_order:
            subcats = list(self.vAssets[area])
            for cat in subcats:
                for asset in self.vAssets[area][cat]:
                    if asset == asset_name:
                        return self.vAssets[area][cat][asset]

        # Failed to fetch asset, return empty structure.
        return {}

    def f_DummyAssets(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_DummyAssets")

        vDummyAssets = []

        vDummy = {}
        vDummy["name"] = "dummy"
        vDummy["slug"] = ""
        vDummy["type"] = ""
        vDummy["files"] = []
        vDummy["maps"] = []
        vDummy["lods"] = []
        vDummy["sizes"] = []
        vDummy["vars"] = []
        vDummy["date"] = ""
        vDummy["credits"] = 0
        vDummy["categories"] = []
        vDummy["preview"] = ""
        vDummy["thumbnails"] = []

        for i in range(cTB.vSettings["page"]):
            vDummyAssets.append(vDummy)

        return vDummyAssets

    def f_UpdateData(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_UpdateData")

        vDFile = cTB.gSettingsDir + "/Poliigon_Data.ini"

        vConfig = ConfigParser.ConfigParser()
        vConfig.optionxform = str
        if f_Ex(vDFile):
            vConfig.read(vDFile)

        vArea = "my_assets"

        if vArea in cTB.vAssets.keys():
            for vType in cTB.vAssets[vArea].keys():
                for vAsset in cTB.vAssets[vArea][vType].keys():
                    if not vConfig.has_section(vAsset):
                        vConfig.add_section(vAsset)

                    vConfig.set(vAsset, "id", cTB.vAssets[vArea][vType][vAsset]["id"])
                    vConfig.set(
                        vAsset, "type", cTB.vAssets[vArea][vType][vAsset]["type"]
                    )
                    vConfig.set(
                        vAsset, "date", cTB.vAssets[vArea][vType][vAsset]["date"]
                    )
                    vConfig.set(
                        vAsset,
                        "categories",
                        ";".join(cTB.vAssets[vArea][vType][vAsset]["date"]),
                    )

        with open(vDFile, "w+") as vFile:
            vConfig.write(vFile)

    # .........................................................................

    def f_GetCredits(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetCredits")

        vThread = threading.Thread(target=cTB.f_APIGetCredits)
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    @reporting.handle_function(silent=True)
    def f_APIGetCredits(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_APIGetCredits")

        vReq = cTB._api.get_user_balance()

        if vReq.ok:
            cTB.vUser["credits"] = vReq.body.get("subscription_balance")
            cTB.vUser["credits_od"] = vReq.body.get("ondemand_balance")
        else:
            cTB.print_debug(dbg, "f_APIGetCredits", "ERROR", vReq.error)

    # .........................................................................

    def f_GetUserInfo(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetUserInfo")

        vThread = threading.Thread(target=cTB.f_APIGetUserInfo)
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    @reporting.handle_function(silent=True)
    def f_APIGetUserInfo(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_APIGetUserInfo")

        vReq = cTB._api.get_user_info()

        if vReq.ok:
            cTB.vUser["name"] = vReq.body.get("user")["name"]
            cTB.vUser["id"] = vReq.body.get("user")["id"]
        else:
            cTB.print_debug(dbg, "f_APIGetUserInfo", "ERROR", vReq.error)

    # .........................................................................

    def f_GetSubscriptionDetails(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetSubscriptionDetails")

        vThread = threading.Thread(target=cTB.f_APIGetSubscriptionDetails)
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    @reporting.handle_function(silent=True)
    def f_APIGetSubscriptionDetails(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_APIGetSubscriptionDetails")

        vReq = cTB._api.get_subscription_details()

        if vReq.ok:
            pass
            # TODO(SOFT-93): Set user variables based upon return of request
        else:
            cTB.print_debug(dbg, "f_APIGetSubscriptionDetails", "ERROR", vReq.error)

    # .........................................................................

    def f_QueuePreview(cTB, vAsset, thumbnail_index=0):
        dbg = 0
        cTB.print_separator(dbg, "f_QueuePreview")

        vThread = threading.Thread(target=cTB.f_DownloadPreview,
                                   args=(vAsset, thumbnail_index))
        vThread.daemon = 1
        vThread.start()
        cTB.vThreads.append(vThread)

    @reporting.handle_function(silent=True)
    def f_DownloadPreview(cTB, vAsset, thumbnail_index):
        """Download a single thumbnail preview for a single asset."""
        dbg = 0
        cTB.print_separator(dbg, "f_DownloadPreview")

        if cTB.vSettings["area"] not in ["poliigon", "my_assets"]:
            return

        already_local = 0
        target_file = cTB.f_GetThumbnailPath(vAsset, thumbnail_index)
        target_base, target_ext = os.path.splitext(target_file)

        # Check if a partial or complete download already exists.
        for vExt in [".jpg", ".png", "X.jpg", "X.png"]:
            f_MDir(cTB.gOnlinePreviews)

            vQPrev = os.path.join(cTB.gOnlinePreviews, target_base + vExt)
            if f_Ex(vQPrev):
                cTB.print_debug(dbg, "f_DownloadPreview", vQPrev)
                if "X" in vExt:
                    try:
                        os.rename(vQPrev, vQPrev.replace("X.jpg", ".jpg"))
                    except:
                        os.remove(vQPrev)

                already_local = 1
                break

        if already_local:
            return

        # .....................................................................

        # Download to a temp filename.
        vPrev = os.path.join(cTB.gOnlinePreviews,
                             target_base + "X" + target_ext)

        vURL = None
        for vType in cTB.vAssets[cTB.vSettings["area"]]:
            # One of Models, HDRIs, Textures.
            if vAsset in cTB.vAssets[cTB.vSettings["area"]][vType]:
                cdn_url = (
                    "https://poliigon.com/cdn-cgi/image/"
                    "width={size},sharpen=1,q=75,f=auto/{url}")

                # This specific combo, width=300, sharpen=1, and q=75 will
                # ensure we make use of the same caching as the website.
                if thumbnail_index == 0:
                    base_url = cTB.vAssets[cTB.vSettings["area"]][vType][vAsset]["preview"]
                    vURL = cdn_url.format(size=300, url=base_url)
                else:
                    base_url = cTB.vAssets[cTB.vSettings["area"]][vType][
                        vAsset]["thumbnails"][thumbnail_index - 1]
                    vURL = cdn_url.format(size=1024, url=base_url)
                break

        if vURL:
            cTB.print_debug(dbg, "f_DownloadPreview", vPrev, vURL)

            resp = cTB._api.download_preview(vURL, vPrev)
            if resp.ok:
                if f_Ex(vPrev):
                    if vPrev.endswith("X.png"):
                        try:
                            os.rename(vPrev, vPrev.replace("X.png", ".png"))
                        except:
                            pass
                    else:
                        try:
                            os.rename(vPrev, vPrev.replace("X.jpg", ".jpg"))
                        except:
                            pass

                if thumbnail_index > 0:
                    pass  # Don't load large thumbnail into preview grid.
                elif vAsset not in cTB.vPreviews.keys():
                    if os.access(target_file, os.W_OK):
                        try:
                            cTB.vPreviews.load(vAsset, target_file, "IMAGE")
                        except KeyError:
                            pass  # Image already loaded into blender.
                        cTB.vPreviews[vAsset].reload()

                        cTB.vRedraw = 1
                        cTB.refresh_ui()
            else:
                print(f"Encountered preview download error: {len(resp.error)}")
                reporting.capture_message(
                    "download_preview_error", resp.error, 'error')
        else:
            reporting.capture_message(
                "download_preview_error",
                f"Failed to find preview url for {vAsset}",
                'error')

        # Always remove from download queue (can have thread conflicts, so try)
        try:
            cTB.vPreviewsDownloading.remove(vAsset)
        except ValueError:  # Already removed.
            pass

    # .........................................................................

    def check_if_purchase_queued(cTB, asset_id):
        """Checks if an asset is queued for purchase"""
        queued = asset_id in list(cTB.vPurchaseQueue.keys())
        return queued

    def queue_purchase(cTB, asset_id, asset_data):
        """Adds an asset to the purchase_queue and starts threads"""
        cTB.vPurchaseQueue[asset_id] = asset_data
        cTB.purchase_queue.put(asset_id)
        cTB.print_debug(0, f"Queued asset {asset_id}")

        cTB.purchase_threads = [
            thread for thread in cTB.purchase_threads if thread.is_alive()]

        if len(cTB.purchase_threads) < MAX_PURCHASE_THREADS:
            thread = threading.Thread(target=cTB.purchase_assets_thread)
            thread.daemon = 1
            thread.start()
            cTB.purchase_threads.append(thread)

    @reporting.handle_function(silent=True)
    def purchase_assets_thread(cTB):
        """Thread to purchase queue of assets"""
        while cTB.purchase_queue.qsize() > 0:
            try:
                asset_id = int(cTB.purchase_queue.get_nowait())
            except queue.Empty:
                time.sleep(0.1)
                continue

            if not cTB.vRunning:
                print("Cancelling in progress purchases")
                return

            asset_data = cTB.vPurchaseQueue[asset_id]

            asset = asset_data['name']

            req = cTB._api.purchase_asset(asset_id)
            del cTB.vPurchaseQueue[asset_id]  # Remove regardless, for ui draw

            if req.ok:
                # Append purchased if success, or if the asset is free.
                cTB.vPurchased.append(asset)
                cTB.vAssets["my_assets"][asset_data["type"]][asset] = asset_data

                # Process auto download if setting enabled.
                if cTB.vSettings["auto_download"]:
                    cTB.vDownloadQueue[asset_id] = {
                        "data": asset_data,
                        "size": None,
                        "download_size": None
                    }
                    cTB.queue_download(asset_id)

            else:
                cTB.print_debug(
                    0, f"Failed to purchase asset {asset_id} {asset}",
                    str(req.error), str(req.body))

                # Check the reason for failure.
                if "enough credits" in req.error:
                    reporting.capture_message(
                        "not_enough_credits", asset, "info")
                    ui_err = DisplayError(
                        asset_id=asset_id,
                        asset_name=asset,
                        button_label="Need credits",
                        description=f"{req.error})"
                    )
                else:
                    reporting.capture_message(
                        "purchase_failed", req.error, "error")
                    ui_err = DisplayError(
                        asset_id=asset_id,
                        asset_name=asset,
                        button_label="Failed, retry",
                        description=f"Error during purchase, please try again ({req.error})"
                    )
                cTB.ui_errors.append(ui_err)

            # Clear cached data in index to prompt refresh after purchase
            cTB.vAssetsIndex["my_assets"] = {}

            # Runs in this same thread, and if there are many purchase
            # events then there may be multiple executions of this. It is
            # important that the last purchase always does update the
            # credits balance, so this tradeoff is ok to have overlapping
            # requests potentially.
            cTB.f_APIGetCredits()
            cTB.vRedraw = 1
            cTB.refresh_ui()

    # .........................................................................

    def refresh_data(self, icons_only=False):
        """Reload data structures of the addon to update UI and stale data.

        This function could be called in main or background thread.
        """
        self.print_debug(0, "refresh_data")
        thread = threading.Thread(
            target=self._refresh_data_thread,
            args=(icons_only,))
        thread.daemon = 1
        thread.start()
        self.vThreads.append(thread)

    @reporting.handle_function(silent=True)
    def _refresh_data_thread(self, icons_only):
        """Background thread for the data resets."""

        # Clear out state variables.
        self.vPreviews.clear()
        if icons_only is False:
            self.notifications = []
            self.vPurchased = []

            cTB.vAssetsIndex["poliigon"] = {}
            cTB.vAssetsIndex["my_assets"] = {}

        # Non-background thread requestes
        self.vGettingData = 1
        self.f_GetAssets(
            "my_assets", vMax=5000, vBackground=1)  # Populates vPurchased.
        self.f_GetAssets(vBackground=1)
        if icons_only is False:
            self.f_APIGetCategories()
            self.f_GetLocalAssetsThread()
        self.vGettingData = 0

        if icons_only is False:
            self.f_APIGetCredits()
            self.f_APIGetUserInfo()

        self.vRedraw = 1
        self.refresh_ui()

    def check_if_download_queued(cTB, asset_id):
        """Checks if an asset is queued for download"""
        queued = asset_id in list(cTB.vDownloadQueue.keys())
        return queued

    def get_maps_by_workflow(cTB, maps, workflow):
        maps_to_exclude = {
            "METALNESS": ("GLOSS", "REFL"),
            "REGULAR": (),
            "SPECULAR": ("METALNESS", "ROUGHNESS")
        }


        maps = [m for m in maps if not m.startswith(maps_to_exclude[workflow])]
        return list(set(maps))


    def get_download_data(cTB, asset_data, size=None):
        sizes = [size]
        
        if size in ['',None]:
            if asset_data["type"] == "Textures" :
                sizes = [cTB.vSettings["res"]]
            elif asset_data["type"] == "Models" :
                sizes = [cTB.vSettings["mres"]]
            elif asset_data["type"] == "HDRIs" :
                sizes = [cTB.vSettings["hdri"]]
            elif asset_data["type"] == "Brushes" :
                sizes = [cTB.vSettings["brush"]]
            
            cTB.vDownloadQueue[asset_data["id"]]['size'] = sizes[0]
        
        download_data = {
            'assets': [
                {
                    'id': asset_data['id'],
                    'name': asset_data['name']
                }
            ],
            'source': 'toolbox',
        }
        
        if asset_data['type'] in ['Textures','HDRIs'] :
            download_data['assets'][0]['workflows'] = []
            if 'METALNESS' in asset_data['workflows'] :
                download_data['assets'][0]['workflows'] = ['METALNESS']
            elif 'REGULAR' in asset_data['workflows'] :
                download_data['assets'][0]['workflows'] = ['REGULAR']
            elif 'SPECULAR' in asset_data['workflows'] :
                download_data['assets'][0]['workflows'] = ['SPECULAR']

            maps = cTB.get_maps_by_workflow(asset_data['maps'], 
                download_data['assets'][0]['workflows'][0])
            
            download_data['assets'][0]['type_codes'] = maps
            
        elif asset_data['type'] == 'Models' :
            download_data['assets'][0]['lods'] = int(cTB.vSettings["download_lods"])
            
            download_data['assets'][0]['softwares'] = ['ALL_OTHERS']
            
        elif asset_data['type'] == 'Brushes' :
            # No special data needed for Brushes
            pass
        
        download_data['assets'][0]['sizes'] = [size for size in sizes if size in asset_data['sizes']]
        if not len(download_data['assets'][0]['sizes']) :
            for size in ['4K','3K','2K','1K'] :
                if size in asset_data['sizes'] :
                    download_data['assets'][0]['sizes'] = [size]
                    break
        
        return download_data

    def queue_download(cTB, asset_id):
        """Adds an asset to the purchase_queue and starts thread if necessary"""
        cTB.download_queue.put(asset_id)

        cTB.download_threads = [
            thread for thread in cTB.download_threads if thread.is_alive()]

        if len(cTB.download_threads) < MAX_DOWNLOAD_THREADS:
            thread = threading.Thread(target=cTB.download_assets_thread)
            thread.daemon = 1
            thread.start()
            cTB.download_threads.append(thread)

    @reporting.handle_function(silent=True)
    def download_assets_thread(cTB):
        """Thread to download queue of assets"""
        while cTB.download_queue.qsize() > 0:
            if not cTB.vRunning:
                print("Cancelling in progress downloads")
                return

            try:
                asset_id = int(cTB.download_queue.get_nowait())
            except queue.Empty:
                time.sleep(0.1)
                continue

            cTB.download_asset(asset_id)

    def download_asset(cTB, asset_id):
        """Gathers download params and calls download function"""
        asset_data = cTB.vDownloadQueue[asset_id]['data']
        size = cTB.vDownloadQueue[asset_id]['size']
        asset = asset_data["name"]
        atype = asset_data["type"]

        download_data = cTB.get_download_data(asset_data, size=size)

        source_dir = cTB.vSettings["library"]
        primary_files = []
        add_files = []
        if asset in cTB.vAssets["local"][atype].keys():
            for file in cTB.vAssets["local"][atype][asset]["files"]:
                if f_Ex(file):
                    if file.split(asset, 1)[0] == source_dir:
                        primary_files.append(file)
                    else:
                        add_files.append(file)

            cTB.print_debug(1, "download_asset", 
                            "Found asset files in primary library:",
                            primary_files)
            if not len(primary_files):
                # Asset must be located in an additional directory
                #
                # Always download new maps to the highest-level directory
                # containing asset name, regardless of any existing (sub)
                # structure within that directory
                if len(add_files):
                    file = add_files[0]
                    if asset in os.path.dirname(file):
                        source_dir = file.split(asset, 1)[0]
                        cTB.print_debug(1, "download_asset", source_dir)

        dst_file = os.path.join(source_dir, asset + ".zip")
        cTB.vDownloadQueue[asset_id]['download_file'] = dst_file + "dl"

        res = cTB._api.download_asset(
            asset_id, download_data, dst_file, callback=cTB.download_update)

        if res.ok:
            pass
        elif res.error == api.ERR_USER_CANCEL_MSG:
            reporting.capture_message(
                "user_cancelled_download", asset_id, "info")
        elif not res.ok:
            reporting.capture_message(
                "download_asset_failed", res.error, "error")
            ui_err = DisplayError(
                asset_id=asset_id,
                asset_name=asset,
                button_label="Failed, retry",
                description=f"Error during download, please try again ({res.error})"
            )
            del cTB.vDownloadQueue[asset_id]
            cTB.ui_errors.append(ui_err)
            cTB.vRedraw = 1
            return

        asset_dir = os.path.splitext(dst_file)[0]

        if f_Ex(asset_dir):
            asset_files = []
            for path, dirs, files in os.walk(asset_dir):
                asset_files += [os.path.join(path, file) for file in files]

            # Ensure previously found asset files are added back
            asset_files += primary_files + add_files
            asset_files = list(set(asset_files))

            cTB.vAssets["local"][atype][asset] = cTB.build_local_asset_data(
                asset, atype, asset_files)

        del cTB.vDownloadQueue[asset_id]

        # cTB.refresh_ui() does not work, set the vRedraw so handler picks up.
        cTB.vRedraw = 1

    def should_continue_asset_download(self, asset_id):
        """Check for any user cancel presses."""
        if asset_id in self.vDownloadCancelled:
            self.vDownloadCancelled.remove(asset_id)
            return False
        return True

    def download_update(self, asset_id, download_size):
        """Updates info for download progress bar, return false to cancel."""
        if asset_id in cTB.vDownloadQueue.keys():
            self.vDownloadQueue[asset_id]['download_size'] = download_size
            self.refresh_ui()
        return self.should_continue_asset_download(asset_id)

    def reset_asset_error(self, asset_id=None, asset_name=None):
        """Resets any prior errors for this asset, such as download issue."""
        for err in self.ui_errors:
            if asset_id and err.asset_id == asset_id:
                self.ui_errors.remove(err)
                self.print_debug(0, "Reset error from id", err)
            elif asset_name and err.asset_name == asset_name:
                self.ui_errors.remove(err)
                self.print_debug(0, "Reset error from name", err)

    # .........................................................................

    def f_BuildMat(cTB, vAsset, vSize, vTextures, vType, vOperator, vLOD=None):
        dbg = 0
        cTB.print_separator(dbg, "f_BuildMat")
        cTB.print_debug(dbg, "f_BuildMat", vAsset, vSize, str(vTextures), vType)

        vMName = vAsset + "_" + vSize

        # Ensure we are only using textures of the input size
        sized_textures = []
        for tex in vTextures:
            match_object = re.search(r"_(\d+K)[_\.]", os.path.basename(tex))
            if match_object:
                size = match_object.group(1)
                if size == vSize:
                    sized_textures.append(tex)
            elif vSize == "PREVIEW":
                sized_textures.append(tex)

        if not sized_textures:
            msg = f"No textures found with size {vSize} for {vAsset}!"
            if vOperator:
                vOperator.report({"ERROR"}, msg)
            reporting.capture_message("build_mat_error", msg, "error")
            return None
        vTextures = sized_textures

        if vMName in bpy.data.materials.keys():
            return bpy.data.materials[vMName]

        vCurMats = [vM for vM in bpy.data.materials]

        vMTexs = [vT for vT in vTextures if f_FName(vT).endswith("METALNESS")]
        vSTexs = [vT for vT in vTextures if f_FName(vT).endswith("SPECULAR")]
        vRTexs = [vT for vT in vTextures if vT not in vMTexs and vT not in vSTexs]

        if len(vMTexs) >= 4:
            vTextures = vMTexs + vRTexs
        elif len(vSTexs) >= 4:
            vTextures = vSTexs + vRTexs
        elif len(vRTexs) >= 4:
            vTextures = vRTexs
        elif vSize == "PREVIEW":
            pass
        else:
            return None

        # Pick the first variant
        var_name = None
        for f in vTextures:
            basename = os.path.basename(f).upper()
            if "_VAR" in basename:
                if var_name is None:
                    var_name = basename
                elif var_name > basename:
                    var_name = basename

        cTB.print_debug(dbg, "=" * 100)

        cTB.print_debug(dbg, "Building Poliigon Material : " + vAsset)
        cTB.print_debug(dbg, "Size : " + vSize)
        cTB.print_debug(dbg, "Textures :")

        vTexs = {}
        for vF in vTextures:
            basename = os.path.basename(vF)
            vSplit = f_FName(vF).split("_")
            if vSplit[-1] in ["SPECULAR", "METALNESS"]:
                vSplit[-1] = None

            if "AO" in vSplit and not cTB.vSettings["use_ao"]:
                continue
            if (
                any(vS for vS in ["BUMP", "BUMP16"] if vS in vSplit)
                and not cTB.vSettings["use_bump"]
            ):
                continue
            if (
                any(vS for vS in ["DISP", "DISP16"] if vS in vSplit)
                and not cTB.vSettings["use_disp"]
            ):
                continue
            if (
                any(vS for vS in ["DISP16", "BUMP16", "NRM16"] if vS in vSplit)
                and not cTB.vSettings["use_16"]
            ):
                continue
            if vLOD != None:
                if "LOD" in basename and vLOD not in basename:
                    continue
                if "NRM" in basename and vLOD not in basename:
                    continue

            if "COL" in vSplit:
                if var_name is not None and var_name != basename.upper():
                    continue

            vMap = [vT for vT in cTB.vMaps if vT in vSplit]
            if len(vMap) and vSize in vSplit + ["PREVIEW"]:
                vTexs[vMap[0]] = vF

                cTB.print_debug(dbg, " " + basename)

        # .....................................................................

        vTemplate = cTB.gScriptDir + "/poliigon_material_template.blend"
        if vAsset.startswith("Rock") and any(
            vT for vT in ["BUMP", "BUMP16"] if vT in vTexs.keys()
        ):
            vTemplate = cTB.gScriptDir + "/poliigon_material_template_rock.blend"
        elif any(vT for vT in ["BUMP", "BUMP16"] if vT in vTexs.keys()) and not any(
            vT for vT in ["DISP", "DISP16"] if vT in vTexs.keys()
        ):
            vTemplate = cTB.gScriptDir + "/poliigon_material_template_rock.blend"
        elif any(vS for vS in ["Carpet", "Fabric", "Rug"] if vS in vAsset):
            vTemplate = cTB.gScriptDir + "/poliigon_material_template_fabric.blend"
        elif any(vT for vT in ["ALPHAMASKED", "MASK"] if vT in vTexs.keys()):
            vTemplate = cTB.gScriptDir + "/poliigon_material_template_alpha.blend"
        elif "METALNESS" in vTexs.keys():
            vTemplate = cTB.gScriptDir + "/poliigon_material_template_metal.blend"

        # TEMP !!!!!!!!!!!!!!!!!!!!
        vTemplate = cTB.gScriptDir + "/poliigon_material_template.blend"
        # !!!!!!!!!!!!!!!!!!!!

        vUberGroup = None
        vAdjustGroup = None
        vFabricGroup = None
        vMixerGroup = None
        for vN in list(bpy.data.node_groups):
            if "UberMapping" in vN.name:
                if "Aspect Ratio" in [vI.name for vI in vN.inputs]:
                    vUberGroup = vN
            elif "Adjustments" in vN.name:
                if "Hue Adj." in [vI.name for vI in vN.inputs]:
                    vAdjustGroup = vN
            elif "Fabric" in vN.name:
                if "Falloff" in [vI.name for vI in vN.inputs]:
                    vFabricGroup = vN
            elif "Mixer" in vN.name:
                if "Mix Texture Value" in [vI.name for vI in vN.inputs]:
                    vMixerGroup = vN

        with bpy.data.libraries.load(vTemplate, link=0) as (vFrom, vTo):
            vTo.materials = vFrom.materials

        vMatNodeGroup = None

        vMat = [vM for vM in bpy.data.materials if vM not in vCurMats][0]
        vMat.name = vMName

        vMat.poliigon = vType + ";" + vAsset

        vMGroup = None
        for vN in vMat.node_tree.nodes:
            if vN.type == "BSDF_PRINCIPLED":
                if "SSS" in vTexs.keys():
                    vN.inputs["Subsurface"].default_value = 0.02
                
            elif vN.type == "GROUP":
                if "Color Hue Adj." in [vI.name for vI in vN.inputs]:
                    vMGroup = vN
                elif "Mix Texture Value" in [vI.name for vI in vN.inputs]:
                    if vMixerGroup != None:
                        bpy.data.node_groups.remove(vN.node_tree)
                    vMat.node_tree.nodes.remove(vN)

            elif vN.type == "DISPLACEMENT":
                if "DISP" not in vTexs.keys() and "DISP16" not in vTexs.keys():
                    vMat.node_tree.nodes.remove(vN)

        vMGroup.name = vMGroup.label = vMGroup.node_tree.name = vMName

        vOutput = None
        vMUberGroup = None
        vMAdjustGroup = None
        vMFabricGroup = None
        vMMixerGroup = None

        vMNodes = vMGroup.node_tree.nodes
        vMLinks = vMGroup.node_tree.links

        vNormalMap = None
        vBumpMap = None

        vTexNodes = []
        vNodes = []
        vNTrees = [vMNodes]
        for vN in vMNodes:
            if vN.type == "GROUP_OUTPUT":
                vOutput = vN

            elif vN.type == "TEX_IMAGE":
                vTexNodes.append(vN)

            elif vN.type == "NORMAL_MAP":
                vNormalMap = vN

            elif vN.type == "BUMP":
                vBumpMap = vN
            
            # Remove Alpha Multiply Node if no Alpha maps found
            elif vN.name == "Alpha Multiply":
                if not any(vM in vTexs.keys() for vM in ["ALPHAMASKED", "MASK"]):
                    vMNodes.remove(vN)

            elif vN.type == "GROUP":
                vName = vN.name
                if "UberMapping" in vName:
                    if "Aspect Ratio" in [vI.name for vI in vN.inputs]:
                        vMUberGroup = vN
                        if vUberGroup != None:
                            vOld = vN.node_tree
                            vN.node_tree = vUberGroup
                            bpy.data.node_groups.remove(vOld)
                elif "Adjustments" in vName:
                    if "Hue Adj." in [vI.name for vI in vN.inputs]:
                        vMAdjustGroup = vN
                        if vAdjustGroup != None:
                            vOld = vN.node_tree
                            vN.node_tree = vAdjustGroup
                            bpy.data.node_groups.remove(vOld)
                    
                    # Remove Alpha Multiply Node if no Alpha maps found
                    if "Alpha" in [vI.name for vI in vN.inputs]:
                        if not any(vM in vTexs.keys() for vM in ["ALPHAMASKED", "MASK"]):
                            vN.inputs["Alpha"].default_value = 1.0
                        
                elif "Fabric" in vName:
                    if "Falloff" in [vI.name for vI in vN.inputs]:
                        if vAsset.startswith("Fabric"):
                            vMFabricGroup = vN
                            if vFabricGroup != None:
                                vOld = vN.node_tree
                                vN.node_tree = vFabricGroup
                                bpy.data.node_groups.remove(vOld)
                        else:
                            vMNodes.remove(vN)
                else:
                    vNNodes = vN.node_tree.nodes
                    vNTrees.append(vNNodes)
                    for vN1 in vNNodes:
                        if vN1.type == "TEX_IMAGE":
                            vTexNodes.append(vN1)

        if vBumpMap != None:
            if "BUMP" not in vTexs.keys() and "BUMP16" not in vTexs.keys():
                vMNodes.remove(vBumpMap)

                if vNormalMap != None:
                    vMLinks.new(
                        vNormalMap.outputs["Normal"], vMAdjustGroup.inputs["Normal"]
                    )

            else:
                vMLinks.new(vBumpMap.outputs["Normal"], vMAdjustGroup.inputs["Normal"])

        for vN in vTexNodes:
            vMap = vN.name
            if vMap == "ALPHA":
                if "MASK" in vTexs.keys():
                    vMap = "MASK"

                    vMat.blend_method = "HASHED"
                    vMat.shadow_method = "CLIP"

            elif vMap == "COLOR":
                if "ALPHAMASKED" in vTexs.keys():
                    vMap = "ALPHAMASKED"

                    vMat.blend_method = "HASHED"
                    vMat.shadow_method = "CLIP"
                else:
                    vMap = "COL"

            elif vMap == "BUMP":
                vAddBump = 0
                vMap = "BUMP"
                if "BUMP16" in vTexs.keys():
                    vMap = "BUMP16"

            elif vMap == "DISPLACEMENT":
                vMap = "DISP"
                if "DISP16" in vTexs.keys():
                    vMap = "DISP16"

            elif vMap == "NORMAL":
                vMap = "NRM"
                if "NRM16" in vTexs.keys():
                    vMap = "NRM16"

            if vMap in vTexs.keys():
                if vMap == "ROUGHNESS":
                    vMLinks.new(vN.outputs["Color"], vMAdjustGroup.inputs["ROUGHNESS"])

                if vMap in ["DISP", "DISP16"]:
                    if cTB.prefs.use_micro_displacements:
                        vMGroup.inputs["Displacement Strength"].default_value = 0.05
                        if "NRM" or "NRM16" in vTexs.keys():
                            # Micro displacement does not work with normal and displacement maps at
                            # the same time, so disable normal (if displacement used).
                            vMGroup.inputs["Normal Strength"].default_value = 0
                            if vOperator != None:
                                vOperator.report(
                                    {"INFO"},
                                    "Disabling normals due to use of micro displacements."
                                )
                    else:
                        vMGroup.inputs["Displacement Strength"].default_value = 0.0

            
                engine = bpy.context.scene.render.engine
                if engine == "BLENDER_EEVEE" and vMap == "TRANSMISSION":
                    vMat.use_screen_refraction = True
                    vMat.refraction_depth = 1

                vTName = f_FName(vTexs[vMap])
                if vTName in bpy.data.images.keys():
                    vImage = bpy.data.images[vTName]
                else:
                    vImage = bpy.data.images.load(vTexs[vMap])
                    vImage.name = vTName

                vN.image = vImage
                if vMap in [
                    "AO",
                    "BUMP",
                    "BUMP16",
                    "DISP",
                    "DISP16",
                    "GLOSS",
                    "MASK",
                    "METALNESS",
                    "ROUGHNESS",
                    "NRM",
                    "NRM16",
                    "TRANSMISSION"
                ]:
                    if hasattr(vN, "color_space"):
                        vN.color_space = "NONE"
                    elif vN.image and hasattr(vN.image, "colorspace_settings"):
                        vN.image.colorspace_settings.name = "Non-Color"

            else:
                for vNT in vNTrees:
                    try:
                        vNT.remove(vN)
                    except:
                        pass

        if vMFabricGroup != None:
            vMLinks.new(
                vMAdjustGroup.outputs["Base Color"], vMFabricGroup.inputs["Base Color"]
            )
            vMLinks.new(
                vMAdjustGroup.outputs["Roughness"], vMFabricGroup.inputs["Roughness"]
            )
            vMLinks.new(vMAdjustGroup.outputs["Normal"], vMFabricGroup.inputs["Normal"])

            vMLinks.new(
                vMFabricGroup.outputs["Base Color"], vOutput.inputs["Base Color"]
            )
            vMLinks.new(vMFabricGroup.outputs["Roughness"], vOutput.inputs["Roughness"])

        if vOperator != None:
            vOperator.report({"INFO"}, "Material Created : " + vAsset + "_" + vSize)

        print("=" * 100)

        return vMat

    def f_BuildBackplate(cTB, vAsset, vName, vFile):
        """Create the backplate mateiral and apply to existing or a new obj."""
        dbg = 0
        cTB.print_separator(dbg, "f_BuildBackplate")

        if vName in bpy.data.materials:
            vMat = bpy.data.materials[vName]

            vImage = bpy.data.images[vName]

        else:
            # TODO: Move material definition into a material handler.
            bpy.data.materials.new(vName)

            vMat = bpy.data.materials[vName]

            vMat.use_nodes = 1

            vMNodes = vMat.node_tree.nodes
            vMLinks = vMat.node_tree.links

            vMNodes.remove(vMNodes["Principled BSDF"])

            vCoords = vMNodes.new(type="ShaderNodeTexCoord")
            vCoords.location = mathutils.Vector((-650, 360))

            vTex = vMNodes.new("ShaderNodeTexImage")
            vTex.name = "DIFF"
            vTex.label = "DIFF"
            vTex.location = mathutils.Vector((-450, 360))

            vBG = vMNodes.new("ShaderNodeBackground")
            vBG.location = mathutils.Vector((-145, 225))
            vBG.inputs[1].default_value = 2

            vMix = vMNodes.new("ShaderNodeMixShader")
            vMix.location = mathutils.Vector((60, 300))

            vLight = vMNodes.new("ShaderNodeLightPath")
            vLight.location = mathutils.Vector((-145, 570))

            if vName in bpy.data.images:
                vImage = bpy.data.images[vName]
            else:
                vImage = bpy.data.images.load(vFile)
                vImage.name = vName
            vTex.image = vImage

            vMLinks.new(vCoords.outputs["UV"], vTex.inputs["Vector"])
            vMLinks.new(vTex.outputs["Color"], vBG.inputs["Color"])
            vMLinks.new(vBG.outputs[0], vMix.inputs[2])
            vMLinks.new(vLight.outputs[0], vMix.inputs[0])
            vMLinks.new(vMix.outputs[0], vMNodes["Material Output"].inputs[0])

        vMat.poliigon = "Textures;" + vAsset

        if bpy.context.selected_objects:
            # If there are objects selected, apply backplate to those
            vObjs = list(bpy.context.selected_objects)

        else:
            # Otherwise, create a new object.
            prior_objs = [vO for vO in bpy.data.objects]

            bpy.ops.mesh.primitive_plane_add(
                size=1.0, enter_editmode=False,
                location=bpy.context.scene.cursor.location, rotation=(0, 0, 0)
            )

            vObj = [vO for vO in bpy.data.objects if vO not in prior_objs][0]
            vObjs = [vObj]  # For assignment of material later.
            vObj.name = vName

            vObj.rotation_euler = mathutils.Euler((radians(90.0), 0.0, 0.0), "XYZ")

            vRatio = vImage.size[0] / vImage.size[1]

            vH = 5.0
            if bpy.context.scene.unit_settings.length_unit == "KILOMETERS":
                vH = 5.0 / 1000
            elif bpy.context.scene.unit_settings.length_unit == "CENTIMETERS":
                vH = 5.0 * 100
            elif bpy.context.scene.unit_settings.length_unit == "MILLIMETERS":
                vH = 5.0 * 1000
            elif bpy.context.scene.unit_settings.length_unit == "MILES":
                vH = 16.0 / 5280
            elif bpy.context.scene.unit_settings.length_unit == "FEET":
                vH = 16.0
            elif bpy.context.scene.unit_settings.length_unit == "INCHES":
                vH = 16.0 * 12

            vW = vH * vRatio

            vObj.dimensions = mathutils.Vector((vW, vH, 0))

            vObj.delta_scale[0] = 1
            vObj.delta_scale[1] = 1
            vObj.delta_scale[2] = 1

            bpy.ops.object.select_all(action="DESELECT")
            try:
                vObj.select_set(True)
            except:
                vObj.select = True

            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        for obj in vObjs:
            obj.active_material = vMat

    # .........................................................................

    def f_GetLocalAssets(cTB, force=0):
        dbg = 0
        cTB.print_separator(dbg, "f_GetLocalAssets")
        
        # This function was taking 3.5s to run at startup, so thrown it into a thread
        
        if not force and (time.time() - cTB.vGotLocalAssets) < 60*5 :
            return
        
        if not cTB.vGettingLocalAssets :
            cTB.vGettingLocalAssets = 1
            
            vThread = threading.Thread(target=cTB.f_GetLocalAssetsThread)
            vThread.daemon = 1
            vThread.start()
            cTB.vThreads.append(vThread)
        else:
            cTB.print_debug(1, "Flagging to check local assets again.")
            cTB.vRerunGetLocalAssets = True


    #@timer
    @reporting.handle_function(silent=True)
    def f_GetLocalAssetsThread(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetLocalAssetsThread")

        for vType in cTB.vAssetTypes:
            cTB.vAssets["local"][vType] = {}

        vGetAssets = {}
        vModels = []
        vHDRIs = []
        vBrushes = []

        vPrevs = {}
        gLatest = {}
        for vDir in [cTB.vSettings["library"]] + cTB.vSettings["add_dirs"]:
            if vDir in cTB.vSettings["disabled_dirs"]:
                continue

            for vPath, vDirs, vFiles in os.walk(vDir):
                vPath = vPath.replace("\\", "/")

                if "Software" in vPath and not "Blender" in vPath:
                    continue
                
                for vF in vFiles:
                    if vF.startswith("."):
                        continue  # Ignore hidden system files like .DS_Store
                    if f_FExt(vF) in ["", ".zip"]:
                        continue

                    vName, vExt = f_FNameExt(vF)
                    vName = vName.split("_")[0]

                    if vName.startswith("Hdr"):
                        vHDRIs.append(vName)
                        
                    elif vName.startswith("Brush"):
                        vBrushes.append(vName)

                    if any(
                        f_FName(vF).lower().endswith(vS)
                        for vS in [
                            "_atlas",
                            "_sphere",
                            "_cylinder",
                            "_fabric",
                            "_preview1",
                        ]
                    ):
                        if vName not in vGetAssets.keys():
                            vGetAssets[vName] = []
                        
                        vGetAssets[vName].append(vPath + "/" + vF)

                        vFTime = os.path.getctime(vPath + "/" + vF)
                        vFDate = int(
                            (
                                str(datetime.datetime.fromtimestamp(vFTime)).split(" ")[
                                    0
                                ]
                            ).replace("-", "")
                        )

                        if vName not in gLatest.keys():
                            gLatest[vName] = vFTime
                        elif gLatest[vName] < vFTime:
                            gLatest[vName] = vFTime

                    elif vExt.lower() in cTB.vTexExts:
                        if any(vM in vF for vM in cTB.vMaps):
                            if vName not in vGetAssets.keys():
                                vGetAssets[vName] = []

                            vGetAssets[vName].append(vPath + "/" + vF)

                    elif vExt.lower() in cTB.vModExts:
                        if vName not in vGetAssets.keys():
                            vGetAssets[vName] = []

                        vGetAssets[vName].append(vPath + "/" + vF)

                        vGetAssets[vName] += [
                            vPath + "/" + vFl
                            for vFl in vFiles
                            if f_FExt(vFl) in cTB.vTexExts
                        ]

                        if vName not in vModels:
                            vModels.append(vName)

        for vA in sorted(list(vGetAssets.keys())):
            if any(vS in vA for vS in cTB.vModSecondaries):
                vPrnt = vA
                for vS in cTB.vModSecondaries:
                    vPrnt = vPrnt.replace(vS, "")

                if vPrnt in list(vGetAssets.keys()):
                    vGetAssets[vPrnt] += vGetAssets[vA]

                    del vGetAssets[vA]

        for vA in sorted(list(vGetAssets.keys())):
            vType = "Textures"
            if vA in vModels:
                vType = "Models"
            elif vA in vHDRIs:
                vType = "HDRIs"
            elif vA in vBrushes:
                vType = "Brushes"
            
            if vType not in cTB.vAssets["local"].keys():
                cTB.vAssets["local"][vType] = {}
            
            # updating the global asset dict here for better UI responsiveness
            cTB.vAssets["local"][vType][vA] = cTB.build_local_asset_data(vA, vType, vGetAssets[vA])

        vSLatest = {}
        for vK in gLatest.keys():
            vSLatest[gLatest[vK]] = vK

        gLatest = [vSLatest[vK] for vK in reversed(sorted(vSLatest.keys()))]
        
        # Need to tag redraw, can't directlly call refresh_ui since
        # this runs on startup.
        cTB.vRedraw = 1
        
        cTB.vGettingLocalAssets = 0
        
        cTB.vGotLocalAssets = time.time()
        if cTB.vRerunGetLocalAssets:
            cTB.vRerunGetLocalAssets = False
            cTB.f_GetLocalAssets()
    
    def build_local_asset_data(cTB, asset, type, files):
        """Builds data dict for asset"""
        files = sorted(list(set(files)))
        
        maps = []
        lods = []
        sizes = []
        vars = []
        preview = None
        for file in files:
            if any(
                f_FName(file).lower().endswith(string)
                for string in [
                    "_atlas",
                    "_sphere",
                    "_cylinder",
                    "_fabric",
                    "_preview1",
                ]
            ):
                preview = file
            else:
                maps += [map for map in cTB.vMaps if map in f_FName(file).split("_")]
                lods += [lod for lod in cTB.vLODs if lod in f_FName(file).split("_") and f_FExt(file) == '.fbx']
                sizes += [size for size in cTB.vSizes if size in f_FName(file).split("_")]
                vars += [var for var in cTB.vVars if var in f_FName(file).split("_")]

        asset_data = {}
        asset_data["name"] = asset
        # asset_data["id"] = 0  # Don't populate id, it's not available here.
        asset_data["type"] = type
        asset_data["files"] = files
        asset_data["maps"] = sorted(list(set(maps)))
        asset_data["lods"] = [lod for lod in cTB.vLODs if lod in lods]  #sort
        asset_data["sizes"] = [size for size in cTB.vSizes if size in sizes]  #sort
        asset_data["vars"] = sorted(list(set(vars)))
        asset_data["date"] = max(os.path.getctime(file) for file in files)
        asset_data["credits"] = None
        asset_data["preview"] = preview
        asset_data["thumbnails"] = [preview]
        asset_data["quick_preview"] = []

        return asset_data

    #@timer
    def f_GetSceneAssets(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetSceneAssets")

        vImportedAssets = {}
        for vType in cTB.vAssetTypes:
            vImportedAssets[vType] = {}
        
        for vM in bpy.data.materials:
            try:
                vType, vAsset = vM.poliigon.split(";")
                vAsset = vAsset.split("_")[0]
                if vType == "Textures" and vAsset != "":
                    cTB.print_debug(dbg, "f_GetSceneAssets", vAsset)

                    if vAsset not in vImportedAssets["Textures"].keys():
                        vImportedAssets["Textures"][vAsset] = []

                    if vM not in vImportedAssets["Textures"][vAsset]:
                        vImportedAssets["Textures"][vAsset].append(vM)
            except:
                pass

        for vO in bpy.data.objects:
            try:
                vType, vAsset = vO.poliigon.split(";")
                vAsset = vAsset.split("_")[0]
                if vType == "Models" and vAsset != "":
                    cTB.print_debug(dbg, "f_GetSceneAssets", vAsset)

                    if vAsset not in vImportedAssets["Models"].keys():
                        vImportedAssets["Models"][vAsset] = []

                    if vO not in vImportedAssets["Models"][vAsset]:
                        vImportedAssets["Models"][vAsset].append(vO)
            except:
                pass

        for vI in bpy.data.images:
            try:
                vType, vAsset = vI.poliigon.split(";")
                vAsset = vAsset.split("_")[0]
                if vType in ["HDRIs", "Brushes"] and vAsset != "":
                    cTB.print_debug(dbg, "f_GetSceneAssets", vAsset)

                    if vAsset not in vImportedAssets[vType].keys():
                        vImportedAssets[vType][vAsset] = []
                    
                    vImportedAssets[vType][vAsset].append(vI)
            except:
                pass
        
        cTB.vAssets["imported"] = vImportedAssets

    def f_GetActiveData(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetActiveData")

        cTB.vActiveMatProps = {}
        cTB.vActiveTextures = {}
        cTB.vActiveMixProps = {}

        if cTB.vActiveMat == None:
            return

        vMat = bpy.data.materials[cTB.vActiveMat]

        if cTB.vActiveMode == "mixer":
            vMNodes = vMat.node_tree.nodes
            vMLinks = vMat.node_tree.links
            for vN in vMNodes:
                if vN.type == "GROUP":
                    if "Mix Texture Value" in [vI.name for vI in vN.inputs]:
                        vMat1 = None
                        vMat2 = None
                        vMixTex = None
                        for vL in vMLinks:
                            if vL.to_node == vN:
                                if vL.to_socket.name in ["Base Color1", "Base Color2"]:
                                    vProps = {}
                                    for vI in vL.from_node.inputs:
                                        if vI.is_linked:
                                            continue
                                        if vI.type == "VALUE":
                                            vProps[vI.name] = vL.from_node

                                    if vL.to_socket.name == "Base Color1":
                                        vMat1 = [vL.from_node, vProps]
                                    elif vL.to_socket.name == "Base Color2":
                                        vMat2 = [vL.from_node, vProps]
                                elif vL.to_socket.name == "Mix Texture":
                                    if vN.inputs["Mix Texture"].is_linked:
                                        vMixTex = vL.from_node

                        vProps = {}
                        for vI in vN.inputs:
                            if vI.is_linked:
                                continue
                            if vI.type == "VALUE":
                                vProps[vI.name] = vN

                        cTB.vActiveMixProps[vN.name] = [
                            vN,
                            vMat1,
                            vMat2,
                            vProps,
                            vMixTex,
                        ]

            if cTB.vSettings["mix_props"] == []:
                vK = list(cTB.vActiveMatProps.keys())[0]
                cTB.vSettings["mix_props"] = list(cTB.vActiveMatProps[vK][3].keys())
        else:
            vMNodes = vMat.node_tree.nodes
            for vN in vMNodes:
                if vN.type == "GROUP":
                    for vI in vN.inputs:
                        if vI.type == "VALUE":
                            cTB.vActiveMatProps[vI.name] = vN
                elif vN.type == "BUMP" and vN.name == "Bump":
                    for vI in vN.inputs:
                        if vI.type == "VALUE" and vI.name == "Strength":
                            cTB.vActiveMatProps[vI.name] = vN

            if cTB.vSettings["mat_props"] == []:
                cTB.vSettings["mat_props"] = list(cTB.vActiveMatProps.keys())

            if vMat.use_nodes:
                for vN in vMat.node_tree.nodes:
                    if vN.type == "TEX_IMAGE":
                        if vN.image == None:
                            continue
                        vFile = vN.image.filepath.replace("\\", "/")
                        if f_Ex(vFile):
                            # pType = [vT for vT in vTypes if vT in f_FName(vFile).split('_')]
                            vType = vN.name
                            if vType == "COLOR":
                                vType = "COL"
                            elif vType == "DISPLACEMENT":
                                vType = "DISP"
                            elif vType == "NORMAL":
                                vType = "NRM"
                            cTB.vActiveTextures[vType] = vN
                    elif vN.type == "GROUP":
                        for vN1 in vN.node_tree.nodes:
                            if vN1.type == "TEX_IMAGE":
                                if vN1.image == None:
                                    continue
                                vFile = vN1.image.filepath.replace("\\", "/")
                                if f_Ex(vFile):
                                    # pType = [vT for vT in vTypes if vT in f_FName(vFile).split('_')]
                                    vType = vN1.name
                                    if vType == "COLOR":
                                        vType = "COL"
                                    elif vType == "DISPLACEMENT":
                                        vType = "DISP"
                                    elif vType == "NORMAL":
                                        vType = "NRM"
                                    cTB.vActiveTextures[vType] = vN1
                            elif vN1.type == "BUMP" and vN1.name == "Bump":
                                for vI in vN1.inputs:
                                    if vI.type == "VALUE" and vI.name == "Distance":
                                        cTB.vActiveMatProps[vI.name] = vN1

    def f_GetSelected(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_GetSelected")

        vAObjects = []
        vAMats = []
        vAFaces = {}
        vAAsset = None
        vAMat = None

        if len(bpy.context.selected_objects):
            for vO in bpy.context.selected_objects:
                vMats = [vM.material for vM in vO.material_slots]
                if any(vM for vM in vMats if vM in cTB.vAllMats):
                    if vAMat in [vM.name for vM in vMats if vM != None]:
                        for vA in cTB.vAssets["imported"]["Textures"].keys():
                            if vAMat in [
                                vSM.name for vSM in cTB.vAssets["imported"]["Textures"][vA]
                            ]:
                                vAObjects.append(vO)
                                vAAsset = vA
                                vAMats = vMats
                                cTB.f_GetActiveData()
                                break
                    else:
                        vAAsset = None
                        for vMat in vMats:
                            if vMat == None:
                                continue
                            if vAAsset != None:
                                break
                            for vA in cTB.vAssets["imported"]["Textures"].keys():
                                if vMat in cTB.vAssets["imported"]["Textures"][vA]:
                                    if vAAsset != None:
                                        break
                                    vAObjects.append(vO)
                                    vAAsset = vA
                                    vAMat = vMat.name
                                    vAMats = vMats
                                    cTB.f_GetActiveData()
                                    break
        else:
            for vO in bpy.context.scene.objects:
                if not vO.mode == "EDIT":
                    continue

                vMats = [vM.material for vM in vO.material_slots]
                if any(vM for vM in vMats if vM in cTB.vAllMats):
                    if vAMat in [vM.name for vM in vMats if vM != None]:
                        for vA in cTB.vAssets["imported"]["Textures"].keys():
                            if vAMat in [
                                vSM.name for vSM in cTB.vAssets["imported"]["Textures"][vA]
                            ]:
                                vAObjects.append(vO)
                                vAAsset = vA
                                vAMats = vMats
                                cTB.f_GetActiveData()
                                break
                    else:
                        vAAsset = None
                        for vMat in vMats:
                            if vMat == None:
                                continue
                            if vAAsset != None:
                                break
                            for vA in cTB.vAssets["imported"]["Textures"].keys():
                                if vMat in cTB.vAssets["imported"]["Textures"][vA]:
                                    if vAAsset != None:
                                        break
                                    vAObjects.append(vO)
                                    vAAsset = vA
                                    vAMat = vMat.name
                                    vAMats = vMats
                                    cTB.f_GetActiveData()
                                    break

        if len(vAObjects):
            vAFaces = {}
            for vO in vAObjects:
                vAFaces[vO.name] = []
                if vO.mode == "EDIT":
                    vMesh = vO.data
                    vBMesh = bmesh.from_edit_mesh(vMesh)
                    for vF in vBMesh.faces:
                        if vF.select:
                            vAFaces[vO.name].append(vF.index)

        cTB.vActiveMats = vAMats
        cTB.vActiveFaces = vAFaces

        if cTB.vActiveObjects != vAObjects:
            cTB.vActiveObjects = vAObjects
            cTB.vActiveMode = "model"
            cTB.vActiveAsset = vAAsset
            cTB.vActiveMat = vAMat

    def f_CheckAssets(cTB):
        dbg = 0
        cTB.print_separator(dbg, "f_CheckAssets")

        if time.time() - cTB.vTimer < 5:
            return
        cTB.vTimer = time.time()

        vAssetNames = []
        for vType in cTB.vAssets["my_assets"].keys():
            vAssetNames += cTB.vAssets["my_assets"][vType]

        cTB.print_debug(dbg, "f_CheckAssets", "New Assets :")
        
        vZips = []
        cTB.vNewAssets = []
        for vDir in [cTB.vSettings["library"]] + cTB.vSettings["add_dirs"]:
            for vPath, vDirs, vFiles in os.walk(vDir):
                vPath = vPath.replace("\\", "/")
                for vF in vFiles:
                    if vF.endswith(".zip"):
                        if vPath + vF not in vZips:
                            vZips.append(vPath + vF)

                    elif "COL" in vF or vF.startswith("Back"):
                        vName = f_FName(vF).split("_")
                        if vName[-1] == "SPECULAR":
                            continue
                        if vName[0] not in vAssetNames:
                            cTB.vNewAssets.append(vName[0])

                            # if vDBG : print(vDBGi,"-",vName[0])

        if len(vZips) and cTB.vSettings["unzip"]:
            cTB.print_debug(dbg, "f_CheckAssets", "Zips :")

            for vZFile in vZips:
                vName = f_FName(vZFile).split("_")[0]
                cTB.print_debug(dbg, "f_CheckAssets", "-", vName, " from ", vZFile)

                gLatest = 0
                for vType in cTB.vAssets["local"].keys():
                    if vName in cTB.vAssets["local"][vType].keys():
                        for vF in cTB.vAssets["local"][vType][vName]["files"]:
                            try:
                                vFDate = datetime.datetime.fromtimestamp(
                                    os.path.getctime(vF)
                                )
                                vFDate = str(vFDate).split(" ")[0].replace("-", "")
                                vFDate = int(vFDate)
                                if vFDate > gLatest:
                                    gLatest = vFDate
                            except:
                                pass

                        vZDate = int(
                            (
                                str(
                                    datetime.datetime.fromtimestamp(
                                        os.path.getctime(vF)
                                    )
                                ).split(" ")[0]
                            ).replace("-", "")
                        )
                        if vZDate < vFDate:
                            continue

        cTB.f_GetLocalAssets()

    # .........................................................................

    def f_Label(cTB, vWidth, vText, vContainer, vIcon=None, vAddPadding=False):
        """Text wrap a label based on indicated width."""
        # TODO: Move this to UI class ideally.
        dbg = 0
        cTB.print_separator(dbg, "f_Label")

        vWords = [vW.replace("!@#", " ") for vW in vText.split(" ")]
        vContainerRow = vContainer.row()
        vParent = vContainerRow.column(align=True)
        vParent.scale_y = 0.8  # To make vertical height more natural for text.
        if vAddPadding:
            vParent.label(text="")

        if vIcon:
            vWidth -= 25 * cTB.get_ui_scale()

        vLine = ""
        vFirst = True
        for vW in vWords:
            vLW = 15
            vLineN = vLine + vW + " "
            for vC in vLineN:
                if vC in "ABCDEFGHKLMNOPQRSTUVWXYZmw":
                    vLW += 9
                elif vC in "abcdeghknopqrstuvxyz0123456789":
                    vLW += 6
                elif vC in "IJfijl .":
                    vLW += 3

            vLW *= cTB.get_ui_scale()

            if vLW > vWidth:
                if vFirst:
                    if vIcon == None:
                        vParent.label(text=vLine)
                    else:
                        vParent.label(text=vLine, icon=vIcon)
                    vFirst = False

                else:
                    if vIcon == None:
                        vParent.label(text=vLine)
                    else:
                        vParent.label(text=vLine, icon="BLANK1")

                vLine = vW + " "

            else:
                vLine += vW + " "

        if vLine != "":
            if vIcon == None:
                vParent.label(text=vLine)
            else:
                if vFirst:
                    vParent.label(text=vLine, icon=vIcon)
                else:
                    vParent.label(text=vLine, icon="BLANK1")        
        if vAddPadding:
            vParent.label(text="")

    # .........................................................................

    def f_GetThumbnailPath(self, asset, index):
        """Return the best fitting thumbnail preview for an asset.

        The primary grid UI preview will be named asset_preview1.png,
        all others will be named such as asset_preview1_1K.png
        """
        if index == 0:
            # 0 is the small grid preview version of _preview1.

            # Support legacy option of loading .jpg files, check that first.
            thumb = os.path.join(cTB.gOnlinePreviews, asset + "_preview1.jpg")
            if not os.path.exists(thumb):
                thumb = os.path.join(
                    cTB.gOnlinePreviews, asset + "_preview1.png")
        else:
            thumb = os.path.join(
                cTB.gOnlinePreviews,
                asset + f"_preview{index}_1K.png")
        return thumb

    def f_GetPreview(cTB, vAsset, index=0):
        """Queue download for a preview if not already local.

        Use a non-zero index to fetch another preview type thumbnail.
        """
        dbg = 0
        cTB.print_separator(dbg, "f_GetPreview")

        if vAsset == "dummy":
            return

        if vAsset in cTB.vPreviews:
            return cTB.vPreviews[vAsset].icon_id

        f_MDir(cTB.gOnlinePreviews)

        vPrev = cTB.f_GetThumbnailPath(vAsset, index)

        if os.path.exists(vPrev):
            try:
                cTB.vPreviews.load(vAsset, vPrev, "IMAGE")
                cTB.vPreviews[vAsset].reload()
            except KeyError:
                pass  # Already exists.

            cTB.print_debug(dbg, "f_GetPreview", vPrev)

            return cTB.vPreviews[vAsset].icon_id

        if vAsset not in cTB.vPreviewsDownloading:
            cTB.vPreviewsDownloading.append(vAsset)
            cTB.f_QueuePreview(vAsset, index)

        return None

    def f_GetClosestSize(cTB, vSizes, vSize):
        if vSize not in vSizes:
            x = cTB.vSizes.index(vSize)
            for i in range(len(cTB.vSizes)):
                if x - i >= 0:
                    if cTB.vSizes[x - i] in vSizes:
                        vSize = cTB.vSizes[x - i]
                        break
                if x + i < len(cTB.vSizes):
                    if cTB.vSizes[x + i] in vSizes:
                        vSize = cTB.vSizes[x + i]
                        break

        return vSize

    def f_GetSize(cTB, vName):
        for vSz in cTB.vSizes :
            if vSz in vName.split('_') :
                return vSz

        return None

    def f_GetClosestLod(cTB, vLods, vLod):
        if vLod not in vLods:
            x = cTB.vLODs.index(vLod)
            for i in range(len(cTB.vLODs)):
                if x - i >= 0:
                    if cTB.vSizes[x - i] in vLods:
                        vLod = cTB.vLODs[x - i]
                        break
                if x + i < len(cTB.vLODs):
                    if cTB.vLODs[x + i] in vLods:
                        vLod = cTB.vLODs[x + i]
                        break

        return vLod
    
    def f_GetLod(cTB, vName):
        for vL in cTB.vLODs :
            if vL in vName :
                return vL
        return None

    def f_GetVar(cTB, vName):
        vVar = None
        for vV in cTB.vVars :
            if vV in vName :
                return vV
        return vVar

    # .........................................................................

    def check_icon_reload_interval(self):
        """Checks if too little time has elapsed since last page change.

        If user cycles through pages too quickly, icons can fail to load even
        if already downloaded. This is a blender limitation.
        """
        now = time.time()
        if now - self.vLastPageChange < self.vReloadTriggerInterval:
            bpy.app.timers.register(f_icon_refresh_interval,
                                    first_interval=self.vReloadTriggerInterval)
        self.vLastPageChange = now

    # .........................................................................
    def get_verbose(self):
        """User preferences call wrapper, separate to support test mocking."""
        prefs = bpy.context.preferences.addons.get(__package__, None)
        # Fallback, if command line and using the standard install name.
        if not prefs:
            addons = bpy.context.preferences.addons
            prefs = addons.get("poliigon-addon-blender", None)

        if prefs:
            return prefs.preferences.verbose_logs
        else:
            return None

    def get_prefs(self):
        """User preferences call wrapper, separate to support test mocking."""
        prefs = bpy.context.preferences.addons.get(__package__, None)
        # Fallback, if command line and using the standard install name.
        if not prefs:
            addons = bpy.context.preferences.addons
            prefs = addons.get("poliigon-addon-blender", None)

        return prefs.preferences

    @reporting.handle_function(silent=True, transact=False)
    def print_separator(self, dbg, logvalue):
        """Print out a separator log line with a string value logvalue.

        Cache based on args up to a limit, to avoid excessive repeat prints.
        All args must be flat values, such as already casted to strings, else
        an error will be thrown.
        """
        if self.get_verbose() or dbg:
            self._cached_print("-" * 50 + "\n" + str(logvalue))

    @reporting.handle_function(silent=True, transact=False)
    def print_debug(self, dbg, *args):
        """Print out a debug statement with no separator line.

        Cache based on args up to a limit, to avoid excessive repeat prints.
        All args must be flat values, such as already casted to strings, else
        an error will be thrown.
        """
        if self.get_verbose() or (dbg and dbg > 0):
            # Ensure all inputs are hashable, otherwise lru_cache fails.
            stringified = [str(arg) for arg in args]
            self._cached_print(*stringified)

    @lru_cache(maxsize=32)
    def _cached_print(self, *args):
        """A safe-to-cache function for printing."""
        print(*args)

    def update_files(self, path):
        """Updates files in the specified path within the addon."""
        dbg = 0
        update_key = "_update"
        files_to_update = [f for f in os.listdir(path)
                           if os.path.isfile(os.path.join(path, f))
                           and os.path.splitext(f)[0].endswith(update_key)]

        for f in files_to_update:
            f_split = os.path.splitext(f)
            tgt_file = f_split[0][:-len(update_key)] + f_split[1]

            try:
                os.replace(os.path.join(path, f), os.path.join(path, tgt_file))
                self.print_debug(dbg, f"Updated {tgt_file}")
            except PermissionError as e:
                reporting.capture_message("file_permission_error", e, "error")
            except OSError as e:
                reporting.capture_message("os_error", e, "error")

        return len(files_to_update) > 0

    def check_update_callback(self):
        """Callback run by the updater instance."""
        # Hack to force it to think update is available
        fake_update = False
        if fake_update:
            cTB.updater.update_ready = True
            cTB.updater.update_data = updater.VersionData(
                version=(1, 0, 0),
                url="https://github.com/poliigon/poliigon-blender-toolbox/")

        # Build notifications and refresh UI.
        if self.updater.update_ready:
            notice = build_update_notification()
            cTB.register_notification(notice)
        cTB.refresh_ui()


# ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


def f_icon_refresh_interval() -> int:
    """Force refresh all icons if no new requests have occurred."""
    now = time.time()
    if now - cTB.vLastPageChange < cTB.vReloadTriggerInterval:
        return  # Don't trigger, another page change has occurred.
    cTB.refresh_data(icons_only=True)


def f_tick_handler() -> int:
    """Called on by blender timer handlers to check toolbox status.

    The returned value signifies how long until the next execution.
    """
    next_call_s = 60  # Long to prevent frequent checks for updates.
    if cTB.vRunning:  # and not cTB.vExit
        cTB.vExit = 0

        # TODO: Move into an async function
        try:
            # Disabled to improve performance
            #cTB.f_CheckAssets()
            pass
        except Exception:
            err = traceback.format_exc()
            print("Check assets encountered an error:")
            print(err)

        # Thread cleanup.
        for vT in list(cTB.vThreads):
            if not vT.is_alive():
                cTB.vThreads.remove(vT)

        # Updater callback.
        if cTB.prefs and cTB.prefs.auto_check_update:
            if cTB.updater.has_time_elapsed(hours=24):
                cTB.updater.async_check_for_update(cTB.check_update_callback)

    return next_call_s


def f_download_handler() -> int:
    """Called on by blender timer handlers to redraw the UI while downloading.

    The returned value signifies how long until the next execution.
    """
    next_call_s = 1
    combined_keys = list(cTB.vDownloadQueue.keys()) + list(cTB.vQuickPreviewQueue.keys())
    if len(combined_keys) or cTB.vRedraw:
        cTB.vRedraw = 0
        next_call_s = 0.1
        cTB.refresh_ui()
        
        # Automatic import after download
        imports = [
            asset for asset in list(cTB.vDownloadQueue.keys())
            if 'import' in cTB.vDownloadQueue[asset].keys()]
        if len(imports):
            asset = imports[0]
            asset_data = cTB.vDownloadQueue[asset]
            del(cTB.vDownloadQueue[asset])
            if asset_data['data']['type'] == 'Textures':
                bpy.ops.poliigon.poliigon_material(
                    "INVOKE_DEFAULT", vAsset=asset, vSize=asset_data['size'],
                    vData='@_@_', vType=asset_data['data']['type'], vApply=0)
            elif asset_data['data']['type'] == 'HDRIs':
                bpy.ops.poliigon.poliigon_hdri(
                    "INVOKE_DEFAULT", vAsset=asset, vSize=asset_data['size'])
    
    return next_call_s


@persistent
def f_load_handler(*args):
    """Runs when a new file is opened to refresh data"""
    if cTB.vRunning:
        cTB.f_GetSceneAssets()


# ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


cTB = c_Toolbox()

@atexit.register
def blender_quitting():
    global cTB
    cTB.vRunning = 0


def register(bl_info):
    addon_version = ".".join([str(vV) for vV in bl_info["version"]])
    cTB.register(addon_version)

    cTB.vRunning = 1

    bpy.app.timers.register(
        f_tick_handler, first_interval=0.05, persistent=True)

    bpy.app.timers.register(
        f_download_handler, first_interval=1, persistent=True)

    if f_load_handler not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(f_load_handler)


def unregister():
    if bpy.app.timers.is_registered(f_tick_handler):
        bpy.app.timers.unregister(f_tick_handler)

    if bpy.app.timers.is_registered(f_download_handler):
        bpy.app.timers.unregister(f_download_handler)

    if f_load_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(f_load_handler)

    cTB.vRunning = 0

    # Don't block unregister or closing blender.
    # for vT in cTB.vThreads:
    #    vT.join()

    cTB.vIcons.clear()
    bpy.utils.previews.remove(cTB.vIcons)

    cTB.vPreviews.clear()
    bpy.utils.previews.remove(cTB.vPreviews)
